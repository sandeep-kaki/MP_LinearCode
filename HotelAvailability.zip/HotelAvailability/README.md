# HotelAvailability — Selenium + TestNG + POM Project

## Project Structure

```
HotelAvailability/
│
├── pom.xml                              ← Maven: all dependencies
├── testng.xml                           ← Entry point: right-click → Run
│
└── src/test/java/
    ├── base/
    │   └── BaseTest.java                ← Opens/closes Chrome (@BeforeClass / @AfterClass)
    ├── pages/
    │   ├── HomePage.java                ← Locators + actions for the Search page
    │   └── SearchResultsPage.java       ← Locators + actions for the Results page
    ├── utils/
    │   ├── ConfigReader.java            ← Reads config.properties
    │   └── ExcelUtils.java              ← Reads data.xlsx
    └── tests/
        └── HotelAvailabilityTest.java   ← Two @Test methods (search + sorting)

src/test/resources/testdata/
    ├── config.properties                ← Website URL
    └── data.xlsx                        ← Test input data

screenshots/                             ← Auto-created screenshots during test run
```

---

## The Two Tests Explained

```
@Test(priority = 1)
testHotelSearch()
  → Reads Excel rows
  → Types destination, picks dates, sets adults/rooms
  → Clicks Apply → Search
  → Takes screenshot of search options

@Test(priority = 2, dependsOnMethods = "testHotelSearch")
testRatingSorting()
  → Sorts results by Rating
  → Captures ratings from the page
  → Verifies they are in descending order
  → Takes screenshot of results
```

### Why Two Tests Instead of One?

| Scenario | One Test | Two Tests |
|---|---|---|
| Search fails | Report shows ONE failure but reason is unclear | Report shows: Test 1 FAILED, Test 2 SKIPPED |
| Root cause | Hard to identify | Immediately obvious |
| Responsibility | Mixed | Each test does exactly ONE thing |

### What `dependsOnMethods` Does

If `testHotelSearch` fails → `testRatingSorting` is **automatically skipped**.
This prevents a confusing error like "element not found on results page" when
the real problem was that search never completed.

---

## How to Run

### Step 1 — Open in IntelliJ
File → Open → select the `HotelAvailability` folder

### Step 2 — Load Maven Dependencies
Right-click `pom.xml` → Maven → Reload Project

### Step 3 — Update config.properties
```
appurl=https://www.hotels.com
```

### Step 4 — Update data.xlsx (optional)
| Destination | CheckIn Offset | CheckOut Offset | Adults | Rooms |
|---|---|---|---|---|
| New York | 7 | 9 | 2 | 1 |

> Offset = days from today. If today is March 25 and offset is 7 → April 1.

### Step 5 — Run
Right-click `testng.xml` → Run

---

## After Running

- `screenshots/optionsPage.png`   → search form screenshot
- `screenshots/hotelsListPage.png` → sorted results screenshot
- `test-output/index.html`         → TestNG full HTML report (open in browser)

---

## Key Concepts Used

| Concept | Where | What it does |
|---|---|---|
| `@BeforeClass` | BaseTest | Opens browser once before tests start |
| `@AfterClass` | BaseTest | Closes browser once after all tests end |
| `@Test(priority=1)` | HotelAvailabilityTest | Runs testHotelSearch first |
| `@Test(priority=2, dependsOnMethods=...)` | HotelAvailabilityTest | Runs testRatingSorting second, skips if Test 1 failed |
| `Assert.assertEquals()` | HotelAvailabilityTest | Fails test if actual ≠ expected |
| Page Object (HomePage) | pages/ | Keeps locators and actions together, away from tests |
| `extends BaseTest` | HotelAvailabilityTest | Inherits driver, wait, setup, teardown |
