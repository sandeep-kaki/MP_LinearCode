package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * SearchResultsPage.java — Page Object for the Hotel Results Page
 * ─────────────────────────────────────────────────────────────────────
 * This page appears AFTER clicking the Search button on HomePage.
 *
 * Responsibilities:
 *   1. Sort hotels by rating
 *   2. Capture all hotel ratings from the list
 *   3. Take screenshots
 */
public class SearchResultsPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ── LOCATORS ──────────────────────────────────────────────────────
    private By sortBySelector    = By.xpath("//*[@name='sorting_selector']");
    private By sortByRatingRadio = By.xpath("//*[@data-testid='sorting-index-6']");
    private By sortApplyButton   = By.xpath("//*[@data-testid='filters-popover-apply-button']");
    private By hotelsListItems   = By.xpath("//li[@data-testid='accommodation-list-element']");
    private By ratingValueSpans  = By.xpath(".//span[@itemprop='ratingValue']");

    // ── CONSTRUCTOR ───────────────────────────────────────────────────
    public SearchResultsPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait   = wait;
    }

    // ── ACTIONS ───────────────────────────────────────────────────────

    /**
     * Clicks "Sort by" → selects "Rating" option → clicks Apply
     */
    public void sortByRating() {
        wait.until(ExpectedConditions.elementToBeClickable(sortBySelector)).click();
        driver.findElement(sortByRatingRadio).click();
        driver.findElement(sortApplyButton).click();
        System.out.println("  → Sort by Rating applied.");
    }

    /**
     * Reads all visible hotel ratings from the page.
     * Returns them as a List<Double> e.g. [9.2, 8.7, 8.1, 7.9]
     */
    public List<Double> getRatings() {
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(hotelsListItems));

        List<WebElement> ratingElements = wait.until(
                ExpectedConditions.visibilityOfAllElementsLocatedBy(ratingValueSpans)
        );

        List<Double> ratings = new ArrayList<>();
        for (WebElement el : ratingElements) {
            String text = el.getText().trim();
            if (!text.isEmpty()) {
                ratings.add(Double.parseDouble(text));
            }
        }

        System.out.println("  → Ratings captured: " + ratings);
        return ratings;
    }

    /**
     * Takes a screenshot and returns it as a File.
     * The test class decides the file name and save location.
     */
    public File takeScreenshot() {
        TakesScreenshot ts = (TakesScreenshot) driver;
        return ts.getScreenshotAs(OutputType.FILE);
    }
}
