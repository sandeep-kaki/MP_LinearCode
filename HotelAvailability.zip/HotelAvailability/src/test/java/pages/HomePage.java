package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.LocalDate;

/**
 * HomePage.java — Page Object for the Hotel Search Page
 * ─────────────────────────────────────────────────────────────────────
 * POM RULE: This class contains ONLY two things:
 *   1. LOCATORS  → By objects pointing to elements on this page
 *   2. ACTIONS   → Methods that interact with those elements
 *
 * The test class must NOT have any findElement() calls.
 * All element interactions live here.
 *
 * WHY Page Objects?
 *   If the website changes an XPath, you fix it in ONE place (here),
 *   not scattered across multiple test files.
 */
public class HomePage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ── LOCATORS ──────────────────────────────────────────────────────
    private By destinationInput     = By.xpath("//input[@id='input-auto-complete']");
    private By firstSuggestion      = By.xpath("(//ul[@data-testid='auto-complete-suggestion-list']/li)[1]");
    private By guestSelectorPopover = By.xpath("//*[@data-testid='guest-selector-popover']");
    private By adultsInput          = By.xpath("//input[@name='adults']");
    private By adultsPlusButton     = By.xpath("//button[@data-testid='adults-amount-plus-button']");
    private By adultsMinusButton    = By.xpath("//button[@data-testid='adults-amount-minus-button']");
    private By roomsInput           = By.xpath("//input[@name='rooms']");
    private By roomsPlusButton      = By.xpath("//button[@data-testid='rooms-amount-plus-button']");
    private By roomsMinusButton     = By.xpath("//button[@data-testid='rooms-amount-minus-button']");
    private By applyButton          = By.xpath("//*[@data-testid='guest-selector-apply']");
    private By searchButton         = By.xpath("//*[@data-testid='search-button-with-loader' and @class='_3tjlp_']");

    // ── CONSTRUCTOR ───────────────────────────────────────────────────
    public HomePage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait   = wait;
    }

    // ── ACTIONS ───────────────────────────────────────────────────────

    /** Types destination and clicks the first autocomplete suggestion */
    public void enterDestination(String destination) {
        driver.findElement(destinationInput).clear();
        driver.findElement(destinationInput).sendKeys(destination);
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstSuggestion)).click();
        System.out.println("  → Destination entered: " + destination);
    }

    /** Clicks the check-in date on the calendar */
    public void selectCheckInDate(LocalDate checkInDate) {
        By locator = By.xpath("//button[@data-testid='valid-calendar-day-" + checkInDate + "']");
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).click();
        System.out.println("  → Check-in date selected: " + checkInDate);
    }

    /** Clicks the check-out date on the calendar */
    public void selectCheckOutDate(LocalDate checkOutDate) {
        By locator = By.xpath("//button[@data-testid='valid-calendar-day-" + checkOutDate + "']");
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).click();
        System.out.println("  → Check-out date selected: " + checkOutDate);
    }

    /**
     * Sets the number of adults.
     * Reads the current value, then clicks + or - to reach the desired value.
     */
    public void setAdults(int desiredAdults) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(guestSelectorPopover));

        int current = Integer.parseInt(
                wait.until(ExpectedConditions.visibilityOfElementLocated(adultsInput))
                        .getAttribute("aria-valuenow")
        );
        int diff = desiredAdults - current;

        if (diff > 0) {
            for (int i = 0; i < diff; i++)
                wait.until(ExpectedConditions.elementToBeClickable(adultsPlusButton)).click();
        } else if (diff < 0) {
            for (int i = 0; i < Math.abs(diff); i++)
                wait.until(ExpectedConditions.elementToBeClickable(adultsMinusButton)).click();
        }
        System.out.println("  → Adults set to: " + desiredAdults);
    }

    /**
     * Sets the number of rooms.
     * If rooms > 6, prints a message and quits the browser.
     */
    public void setRooms(int desiredRooms) {
        if (desiredRooms > 6) {
            System.out.println("⚠️ More than 6 rooms not supported. Visit: hotelplanner.com");
            driver.quit();
            return;
        }

        int current = Integer.parseInt(
                wait.until(ExpectedConditions.visibilityOfElementLocated(roomsInput))
                        .getAttribute("aria-valuenow")
        );
        int diff = desiredRooms - current;

        if (diff > 0) {
            for (int i = 0; i < diff; i++)
                wait.until(ExpectedConditions.elementToBeClickable(roomsPlusButton)).click();
        } else if (diff < 0) {
            for (int i = 0; i < Math.abs(diff); i++)
                wait.until(ExpectedConditions.elementToBeClickable(roomsMinusButton)).click();
        }
        System.out.println("  → Rooms set to: " + desiredRooms);
    }

    /** Clicks the Apply button in the guest selector */
    public void clickApply() {
        driver.findElement(applyButton).click();
        System.out.println("  → Apply clicked.");
    }

    /** Clicks the Search button */
    public void clickSearch() {
        driver.findElement(searchButton).click();
        System.out.println("  → Search clicked.");
    }
}
