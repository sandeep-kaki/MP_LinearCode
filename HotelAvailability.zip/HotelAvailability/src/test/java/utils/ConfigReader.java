package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * ConfigReader.java — Reads config.properties file
 * ─────────────────────────────────────────────────────────────────────
 * WHY this class exists:
 *   Instead of writing file-reading code in every class that needs the URL,
 *   we write it once here. Any class can call ConfigReader.getProperty("appurl").
 *
 * HOW the static block works:
 *   The 'static { }' block runs ONCE automatically when this class is first used.
 *   It loads the properties file into memory. After that, getProperty() just
 *   reads from memory — no file reading on every call.
 */
public class ConfigReader {

    private static Properties properties = new Properties();

    static {
        try {
            String path = System.getProperty("user.dir")
                    + "/src/test/resources/testdata/config.properties";

            FileInputStream fis = new FileInputStream(path);
            properties.load(fis);
            fis.close();
            System.out.println("✅ config.properties loaded.");

        } catch (IOException e) {
            throw new RuntimeException("❌ config.properties not found! " + e.getMessage());
        }
    }

    // Call anywhere: ConfigReader.getProperty("appurl")
    public static String getProperty(String key) {
        return properties.getProperty(key);
    }
}
