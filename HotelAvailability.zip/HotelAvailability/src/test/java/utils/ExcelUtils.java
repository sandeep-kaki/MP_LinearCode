package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;

/**
 * ExcelUtils.java — Reads data from .xlsx Excel files
 * ─────────────────────────────────────────────────────────────────────
 * Uses Apache POI library to read Excel files.
 *
 * TWO methods:
 *   getRowCount()  → how many data rows are in the sheet?
 *   getCellData()  → what is the value of a specific cell?
 *
 * WHY convert everything to String?
 *   Excel cells can be numbers, text, dates, formulas.
 *   DataFormatter converts ALL types to plain String safely,
 *   so the test class doesn't have to worry about cell types.
 */
public class ExcelUtils {

    /**
     * Returns the last row number in the sheet.
     * Row 0 = header row, Row 1 onwards = data rows.
     */
    public static int getRowCount(String filePath, String sheetName) throws IOException {
        FileInputStream fis   = new FileInputStream(filePath);
        Workbook workbook     = new XSSFWorkbook(fis);
        Sheet sheet           = workbook.getSheet(sheetName);
        int rowCount          = sheet.getLastRowNum();
        workbook.close();
        fis.close();
        return rowCount;
    }

    /**
     * Returns the value of a specific cell as a String.
     *
     * @param filePath  full path to the .xlsx file
     * @param sheetName sheet tab name e.g. "Sheet1"
     * @param rowNum    row index  (0 = header, 1 = first data row)
     * @param colNum    column index (0 = first column, 1 = second column, ...)
     */
    public static String getCellData(String filePath, String sheetName,
                                     int rowNum, int colNum) throws IOException {
        FileInputStream fis   = new FileInputStream(filePath);
        Workbook workbook     = new XSSFWorkbook(fis);
        Sheet sheet           = workbook.getSheet(sheetName);
        Row row               = sheet.getRow(rowNum);
        Cell cell             = row.getCell(colNum);

        String value = "";
        if (cell != null) {
            DataFormatter formatter = new DataFormatter();
            value = formatter.formatCellValue(cell);
        }

        workbook.close();
        fis.close();
        return value;
    }
}
