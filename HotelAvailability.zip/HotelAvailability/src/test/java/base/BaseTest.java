package base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import utils.ConfigReader;

import java.time.Duration;

/**
 * BaseTest.java  — Parent class for all test classes
 * ─────────────────────────────────────────────────────────────────────
 * LOCATION: src/test/java/base/  ← Important! Must be here, not src/main/java
 *           This ensures TestNG annotations are always found without scope issues.
 *
 * WHY a Base class?
 *   Without BaseTest, every test class would need to repeat the browser
 *   setup and teardown code. BaseTest centralizes that in one place.
 *   Any test class that does "extends BaseTest" gets everything for free.
 *
 * FLOW:
 *   @BeforeClass → runs ONCE before the test class starts → opens Chrome
 *   @AfterClass  → runs ONCE after  the test class ends   → closes Chrome
 *
 * 'protected' on driver and wait means:
 *   Child classes (test classes) can access them directly.
 */
public class BaseTest {

    protected WebDriver driver;
    protected WebDriverWait wait;

    @BeforeClass
    public void setUp() {
        // WebDriverManager auto-downloads the correct ChromeDriver version
        // No need to manually download chromedriver.exe and set the path
        WebDriverManager.chromedriver().setup();

        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();

        // Explicit wait — used when we need to wait for a specific element
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Read URL from config.properties and open the browser
        String url = ConfigReader.getProperty("appurl");
        driver.get(url);

        System.out.println("✅ Browser opened: " + url);
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            System.out.println("✅ Browser closed.");
        }
    }
}
