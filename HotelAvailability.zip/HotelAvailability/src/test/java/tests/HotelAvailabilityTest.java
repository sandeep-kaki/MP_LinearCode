package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SearchResultsPage;
import utils.ExcelUtils;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * HotelAvailabilityTest.java — The Test Class
 * ─────────────────────────────────────────────────────────────────────
 * extends BaseTest → gets driver, wait, @BeforeClass and @AfterClass for free.
 *
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * WHY TWO SEPARATE TESTS?
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 *
 * Previously we had ONE @Test doing two things:
 *   → Search for hotels
 *   → Sort and verify ratings
 *
 * Problem with that approach:
 *   - If search fails, the sorting failure is also shown — but it failed
 *     only BECAUSE search failed. The report is confusing.
 *   - Hard to tell: "did sorting break, or did search break?"
 *
 * With TWO tests:
 *   Test 1 — testHotelSearch()     → only responsible for searching
 *   Test 2 — testRatingSorting()   → only responsible for sort verification
 *
 *   If Test 1 fails → Test 2 is automatically SKIPPED (not failed).
 *   The test-output report clearly shows: "Search failed, Sorting was skipped."
 *   You immediately know the ROOT CAUSE.
 *
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * HOW THE DEPENDENCY WORKS:
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 *
 * @Test(priority = 1)
 *   → TestNG runs this first
 *
 * @Test(priority = 2, dependsOnMethods = "testHotelSearch")
 *   → TestNG runs this second
 *   → BUT if testHotelSearch FAILS or is SKIPPED → this is automatically SKIPPED
 *   → This prevents a confusing "NullPointerException on results page" error
 *
 * Both tests share the SAME driver (from BaseTest @BeforeClass)
 * so the browser stays open between the two tests.
 *
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * EXECUTION ORDER:
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 *   @BeforeClass → setUp()           ← opens Chrome
 *       ↓
 *   @Test(priority=1) testHotelSearch()     ← fills search form, clicks Search
 *       ↓
 *   @Test(priority=2) testRatingSorting()   ← sorts, verifies ratings
 *       ↓
 *   @AfterClass → tearDown()         ← closes Chrome
 */
public class HotelAvailabilityTest extends BaseTest {

    // Path to the Excel test data file
    private String filePath = System.getProperty("user.dir")
            + "/src/test/resources/testdata/data.xlsx";

    // ─────────────────────────────────────────────────────────────────
    // TEST 1 — Search for Hotels
    // Responsibility: Read Excel data, fill the form, click Search
    // ─────────────────────────────────────────────────────────────────
    @Test(priority = 1)
    public void testHotelSearch() throws IOException {

        System.out.println("\n══════════════════════════════════════════");
        System.out.println("TEST 1 STARTED: Hotel Search");
        System.out.println("══════════════════════════════════════════");

        HomePage homePage = new HomePage(driver, wait);
        SearchResultsPage resultsPage = new SearchResultsPage(driver, wait);

        // Read total number of data rows from Excel
        int totalRows = ExcelUtils.getRowCount(filePath, "Sheet1");
        System.out.println("Total data rows in Excel: " + totalRows);

        // Loop through each row and perform the search
        for (int i = 1; i <= totalRows; i++) {

            String destination  = ExcelUtils.getCellData(filePath, "Sheet1", i, 0);
            int checkInOffset   = Integer.parseInt(ExcelUtils.getCellData(filePath, "Sheet1", i, 1));
            int checkOutOffset  = Integer.parseInt(ExcelUtils.getCellData(filePath, "Sheet1", i, 2));
            int adults          = Integer.parseInt(ExcelUtils.getCellData(filePath, "Sheet1", i, 3));
            int rooms           = Integer.parseInt(ExcelUtils.getCellData(filePath, "Sheet1", i, 4));

            System.out.println("\n--- Row " + i + " ---");

            // Calculate actual dates based on today + offset from Excel
            LocalDate today    = LocalDate.now();
            LocalDate checkIn  = today.plusDays(checkInOffset);
            LocalDate checkOut = today.plusDays(checkOutOffset);

            // Perform search actions via HomePage
            homePage.enterDestination(destination);
            homePage.selectCheckInDate(checkIn);
            homePage.selectCheckOutDate(checkOut);
            homePage.setAdults(adults);
            homePage.setRooms(rooms);
        }

        // Click Apply (closes the guest selector popover)
        homePage.clickApply();

        // Take screenshot of the filled search form before clicking Search
        File screenshot = resultsPage.takeScreenshot();
        File savePath   = new File(System.getProperty("user.dir") + "/screenshots/optionsPage.png");
        screenshot.renameTo(savePath);
        System.out.println("📸 Search options screenshot saved → screenshots/optionsPage.png");

        // Click Search — moves browser to the results page
        homePage.clickSearch();

        System.out.println("\n✅ TEST 1 PASSED: Hotel search completed successfully.");
    }

    // ─────────────────────────────────────────────────────────────────
    // TEST 2 — Sort Results and Verify Ratings
    // Responsibility: Sort hotels by rating, verify the sort is correct
    //
    // dependsOnMethods = "testHotelSearch"
    //   → This test runs ONLY if testHotelSearch PASSED.
    //   → If testHotelSearch failed → this test is SKIPPED automatically.
    // ─────────────────────────────────────────────────────────────────
    @Test(priority = 2, dependsOnMethods = "testHotelSearch")
    public void testRatingSorting() throws InterruptedException {

        System.out.println("\n══════════════════════════════════════════");
        System.out.println("TEST 2 STARTED: Sort and Verify Ratings");
        System.out.println("══════════════════════════════════════════");

        SearchResultsPage resultsPage = new SearchResultsPage(driver, wait);

        // Apply "Sort by Rating" on the results page
        resultsPage.sortByRating();

        // Wait for the page to reload with sorted results
        Thread.sleep(3000);

        // Take screenshot of sorted hotel results
        File screenshot = resultsPage.takeScreenshot();
        File savePath   = new File(System.getProperty("user.dir") + "/screenshots/hotelsListPage.png");
        screenshot.renameTo(savePath);
        System.out.println("📸 Hotels list screenshot saved → screenshots/hotelsListPage.png");

        // Capture the ratings displayed on the page
        List<Double> actualRatings = resultsPage.getRatings();

        // Create a sorted version to compare against
        List<Double> expectedRatings = new ArrayList<>(actualRatings);
        Collections.sort(expectedRatings, Collections.reverseOrder()); // highest first

        System.out.println("Actual   (from website) : " + actualRatings);
        System.out.println("Expected (sorted desc)  : " + expectedRatings);

        // Assert — TestNG marks the test FAILED if lists don't match
        Assert.assertEquals(
                actualRatings,
                expectedRatings,
                "❌ Ratings are NOT sorted in descending order!"
        );

        System.out.println("\n✅ TEST 2 PASSED: Ratings are correctly sorted in descending order.");
    }
}
