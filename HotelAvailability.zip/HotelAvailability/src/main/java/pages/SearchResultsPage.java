package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * SearchResultsPage.java  ← Page Object for the Hotel Search Results Page
 *
 * This page appears AFTER clicking the Search button on HomePage.
 *
 * It handles:
 *   - Sorting hotels by rating
 *   - Capturing ratings from the results list
 *   - Taking screenshots
 */
public class SearchResultsPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ─────────────────────────────────────────────
    // LOCATORS
    // ─────────────────────────────────────────────

    private By sortBySelector    = By.xpath("//*[@name='sorting_selector']");
    private By sortByRatingRadio = By.xpath("//*[@data-testid='sorting-index-6']");
    private By sortApplyButton   = By.xpath("//*[@data-testid='filters-popover-apply-button']");

    private By hotelsListItems   = By.xpath("//li[@data-testid='accommodation-list-element']");
    private By ratingValueSpans  = By.xpath(".//span[@itemprop='ratingValue']");

    // ─────────────────────────────────────────────
    // CONSTRUCTOR
    // ─────────────────────────────────────────────

    public SearchResultsPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait   = wait;
    }

    // ─────────────────────────────────────────────
    // ACTIONS
    // ─────────────────────────────────────────────

    /**
     * Clicks "Sort by" → selects "Rating" option → clicks Apply
     */
    public void sortByRating() {
        wait.until(ExpectedConditions.elementToBeClickable(sortBySelector)).click();
        driver.findElement(sortByRatingRadio).click();
        driver.findElement(sortApplyButton).click();
        System.out.println("✅ Sorted by Rating applied.");
    }

    /**
     * Takes a screenshot and returns it as a File object.
     * The test class decides where to save it.
     *
     * Usage in test:
     *   File screenshot = resultsPage.takeScreenshot();
     *   screenshot.renameTo(new File("screenshots/mypage.png"));
     */
    public File takeScreenshot() {
        TakesScreenshot ts = (TakesScreenshot) driver;
        return ts.getScreenshotAs(OutputType.FILE);
    }

    /**
     * Reads all hotel ratings visible on the page and returns them as a List of Doubles.
     *
     * Example return: [9.2, 8.7, 8.5, 7.9]
     */
    public List<Double> getRatings() {
        // First wait for the hotels list to be present
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(hotelsListItems));

        // Then get all rating elements
        List<WebElement> ratingElements = wait.until(
                ExpectedConditions.visibilityOfAllElementsLocatedBy(ratingValueSpans)
        );

        List<Double> ratings = new ArrayList<>();
        for (WebElement element : ratingElements) {
            String ratingText = element.getText().trim();
            if (!ratingText.isEmpty()) {
                ratings.add(Double.parseDouble(ratingText));
            }
        }

        System.out.println("✅ Ratings captured: " + ratings);
        return ratings;
    }
}
