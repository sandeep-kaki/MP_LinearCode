package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.LocalDate;

/**
 * HomePage.java  ← Page Object for the Hotel Search (Home) Page
 *
 * POM Rule: This class only contains TWO things:
 *   1. LOCATORS  → the XPaths/IDs to find elements on this page
 *   2. ACTIONS   → methods that perform actions on those elements
 *
 * The test class should NOT have any findElement() calls.
 * All of that lives here.
 */
public class HomePage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ─────────────────────────────────────────────
    // LOCATORS — all XPaths defined as 'By' objects
    // ─────────────────────────────────────────────

    private By destinationInput      = By.xpath("//input[@id='input-auto-complete']");
    private By firstSuggestion       = By.xpath("(//ul[@data-testid='auto-complete-suggestion-list']/li)[1]");

    private By guestSelectorPopover  = By.xpath("//*[@data-testid='guest-selector-popover']");

    private By adultsInput           = By.xpath("//input[@name='adults']");
    private By adultsPlusButton      = By.xpath("//button[@data-testid='adults-amount-plus-button']");
    private By adultsMinusButton     = By.xpath("//button[@data-testid='adults-amount-minus-button']");

    private By roomsInput            = By.xpath("//input[@name='rooms']");
    private By roomsPlusButton       = By.xpath("//button[@data-testid='rooms-amount-plus-button']");
    private By roomsMinusButton      = By.xpath("//button[@data-testid='rooms-amount-minus-button']");

    private By applyButton           = By.xpath("//*[@data-testid='guest-selector-apply']");
    private By searchButton          = By.xpath("//*[@data-testid='search-button-with-loader' and @class='_3tjlp_']");

    // ─────────────────────────────────────────────
    // CONSTRUCTOR — receives driver and wait from the test class
    // ─────────────────────────────────────────────

    public HomePage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait   = wait;
    }

    // ─────────────────────────────────────────────
    // ACTIONS — one method per action
    // ─────────────────────────────────────────────

    /**
     * Types destination in the search box and clicks the first suggestion
     */
    public void enterDestination(String destination) {
        driver.findElement(destinationInput).clear();
        driver.findElement(destinationInput).sendKeys(destination);
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstSuggestion)).click();
    }

    /**
     * Clicks the check-in date on the calendar
     * The XPath is built dynamically using the date passed in
     */
    public void selectCheckInDate(LocalDate checkInDate) {
        By checkInLocator = By.xpath("//button[@data-testid='valid-calendar-day-" + checkInDate + "']");
        wait.until(ExpectedConditions.visibilityOfElementLocated(checkInLocator)).click();
    }

    /**
     * Clicks the check-out date on the calendar
     */
    public void selectCheckOutDate(LocalDate checkOutDate) {
        By checkOutLocator = By.xpath("//button[@data-testid='valid-calendar-day-" + checkOutDate + "']");
        wait.until(ExpectedConditions.visibilityOfElementLocated(checkOutLocator)).click();
    }

    /**
     * Sets the number of adults by clicking + or - buttons
     * Reads current value first, then calculates how many clicks are needed
     */
    public void setAdults(int desiredAdults) {
        // Wait for the guest popover to be visible before interacting
        wait.until(ExpectedConditions.visibilityOfElementLocated(guestSelectorPopover));

        int currentAdults = Integer.parseInt(
                wait.until(ExpectedConditions.visibilityOfElementLocated(adultsInput))
                        .getAttribute("aria-valuenow")
        );

        int diff = desiredAdults - currentAdults;

        if (diff > 0) {
            // Need to click PLUS 'diff' number of times
            for (int i = 0; i < diff; i++) {
                wait.until(ExpectedConditions.elementToBeClickable(adultsPlusButton)).click();
            }
        } else if (diff < 0) {
            // Need to click MINUS 'diff' number of times
            for (int i = 0; i < Math.abs(diff); i++) {
                wait.until(ExpectedConditions.elementToBeClickable(adultsMinusButton)).click();
            }
        }
        // if diff == 0, current value is already correct, do nothing
    }

    /**
     * Sets the number of rooms by clicking + or - buttons
     * If rooms > 6, prints a message and closes the browser
     */
    public void setRooms(int desiredRooms) {
        if (desiredRooms > 6) {
            System.out.println("⚠️ More than 6 rooms requested. Please visit: hotelplanner.com");
            driver.quit();
            return;
        }

        int currentRooms = Integer.parseInt(
                wait.until(ExpectedConditions.visibilityOfElementLocated(roomsInput))
                        .getAttribute("aria-valuenow")
        );

        int diff = desiredRooms - currentRooms;

        if (diff > 0) {
            for (int i = 0; i < diff; i++) {
                wait.until(ExpectedConditions.elementToBeClickable(roomsPlusButton)).click();
            }
        } else if (diff < 0) {
            for (int i = 0; i < Math.abs(diff); i++) {
                wait.until(ExpectedConditions.elementToBeClickable(roomsMinusButton)).click();
            }
        }
    }

    /**
     * Clicks the "Apply" button inside the guest selector popover
     */
    public void clickApply() {
        driver.findElement(applyButton).click();
    }

    /**
     * Clicks the main "Search" button
     */
    public void clickSearch() {
        driver.findElement(searchButton).click();
    }
}
