package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;

/**
 * ExcelUtils.java
 *
 * This utility class reads data from Excel (.xlsx) files using Apache POI.
 *
 * Two methods:
 *   getRowCount()  → tells how many rows of data are in the sheet
 *   getCellData()  → returns the value of a specific cell as a String
 */
public class ExcelUtils {

    /**
     * Returns the total number of data rows in the given sheet.
     * (Header row is row 0, so data starts from row 1)
     */
    public static int getRowCount(String filePath, String sheetName) throws IOException {
        FileInputStream fis = new FileInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(fis);

        Sheet sheet = workbook.getSheet(sheetName);
        int rowCount = sheet.getLastRowNum(); // row index of the last row

        workbook.close();
        fis.close();

        return rowCount;
    }

    /**
     * Returns the value of a cell as a String.
     *
     * @param filePath  - full path to the .xlsx file
     * @param sheetName - name of the sheet (e.g., "Sheet1")
     * @param rowNum    - row index (0 = header, 1 = first data row)
     * @param colNum    - column index (0 = first column)
     */
    public static String getCellData(String filePath, String sheetName,
                                     int rowNum, int colNum) throws IOException {
        FileInputStream fis = new FileInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(fis);

        Sheet sheet   = workbook.getSheet(sheetName);
        Row row       = sheet.getRow(rowNum);
        Cell cell     = row.getCell(colNum);

        // DataFormatter converts any cell type (number, string, date) to a plain String
        String cellValue = "";
        if (cell != null) {
            DataFormatter formatter = new DataFormatter();
            cellValue = formatter.formatCellValue(cell);
        }

        workbook.close();
        fis.close();

        return cellValue;
    }
}
