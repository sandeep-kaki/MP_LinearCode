package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * ConfigReader.java
 *
 * This utility class reads the config.properties file.
 *
 * Why do we need this?
 *   In the original code, config reading was inside main().
 *   Now we've moved it here so any class can call ConfigReader.getProperty("appurl")
 *   without repeating the file-reading code everywhere.
 *
 * 'static block' means: this code runs ONCE when the class is first loaded.
 */
public class ConfigReader {

    private static Properties properties = new Properties();

    // This block runs automatically once when ConfigReader class is first used
    static {
        try {
            String path = System.getProperty("user.dir")
                    + "/src/test/resources/testdata/config.properties";

            FileInputStream fis = new FileInputStream(path);
            properties.load(fis);
            fis.close();

        } catch (IOException e) {
            throw new RuntimeException("❌ config.properties file not found! " + e.getMessage());
        }
    }

    // Call this anywhere: ConfigReader.getProperty("appurl")
    public static String getProperty(String key) {
        return properties.getProperty(key);
    }
}
