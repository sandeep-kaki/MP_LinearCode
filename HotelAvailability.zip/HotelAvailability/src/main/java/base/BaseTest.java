package base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import utils.ConfigReader;

import java.time.Duration;

/**
 * BaseTest.java
 *
 * This is the PARENT class for all test classes.
 *
 * What it does:
 *   - @BeforeClass → runs ONCE before the test class starts  → sets up Chrome, opens URL
 *   - @AfterClass  → runs ONCE after  the test class ends    → closes Chrome
 *
 * Any test class that extends BaseTest automatically gets the driver and wait objects.
 */
public class BaseTest {

    // 'protected' means child test classes can access these directly
    protected WebDriver driver;
    protected WebDriverWait wait;

    @BeforeClass
    public void setUp() {
        // WebDriverManager automatically downloads and sets up ChromeDriver
        // You no longer need to set System.setProperty("webdriver.chrome.driver", "...")
        WebDriverManager.chromedriver().setup();

        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();

        // WebDriverWait is used for explicit waits (waiting for an element to appear)
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Read the URL from config.properties and open it
        String url = ConfigReader.getProperty("appurl");
        driver.get(url);

        System.out.println("✅ Browser opened: " + url);
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            System.out.println("✅ Browser closed.");
        }
    }
}
