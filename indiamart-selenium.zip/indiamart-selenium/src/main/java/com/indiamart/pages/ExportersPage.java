package com.indiamart.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * Page Object for the IndiaMart Exporters page.
 *
 * Handles TC04:
 *   - Waiting for the page to load
 *   - Reading the "Top Product Categories from India" section title
 *   - Extracting the top 5 category names
 *   - Scrolling to the section for screenshot
 *
 * All XPaths and CSS selectors taken directly from the original working code.
 */
public class ExportersPage {

    private final WebDriver driver;
    private final WebDriverWait wait;
    private final JavascriptExecutor js;

    // ── @FindBy Locators ──────────────────────────────────────────────────────

    /**
     * Section heading – "Top Product Categories from India"
     * NOTE: This uses a Tailwind utility class string as the XPath.
     *       If the heading disappears, inspect the page and update the class value.
     */
    @FindBy(xpath = "//h2[@class='text-center font-normal text-gray-800 mb-6 " +
                    "text-[20px] md:text-[28px] leading-[28px]']")
    private WebElement sectionHeading;

    /**
     * Container used as the scroll target for the screenshot.
     * CSS selector from original code.
     */
    @FindBy(css = "div.px-4.py-8.bg-gray-50")
    private WebElement topCategoriesContainer;

    /**
     * Category name XPath – from original code.
     * Selects anchor tags that have BOTH 'text-base' and 'font-semibold' classes.
     */
    private static final String CATEGORY_XPATH =
            "//a[contains(@class,'text-base') and contains(@class,'font-semibold')]";

    // ── Constructor ───────────────────────────────────────────────────────────

    public ExportersPage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(30));
        this.js     = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    /**
     * Waits until the section heading is visible.
     * Confirms the Exporters page has fully loaded.
     */
    public void waitForPage() {
        wait.until(ExpectedConditions.visibilityOf(sectionHeading));
    }

    /**
     * Returns the heading text (e.g. "Top Product Categories from India").
     * Used in the console output header.
     */
    public String getSectionTitle() {
        return sectionHeading.getText().trim();
    }

    /**
     * Returns the names of the top 5 product categories.
     * Capped at 5 to match the original code.
     */
    public List<String> getTopProductCategories() {
        List<WebElement> els = driver.findElements(By.xpath(CATEGORY_XPATH));
        List<String> categories = new ArrayList<>();
        for (int i = 0; i < Math.min(5, els.size()); i++) {
            String text = els.get(i).getText().trim();
            if (!text.isEmpty()) {
                categories.add(text);
            }
        }
        return categories;
    }

    /**
     * Scrolls the top-categories container into view.
     * Called just before taking the screenshot so the section is fully visible.
     */
    public void scrollToTopCategories() {
        wait.until(ExpectedConditions.visibilityOf(topCategoriesContainer));
        js.executeScript("arguments[0].scrollIntoView(true)", topCategoriesContainer);
    }
}
