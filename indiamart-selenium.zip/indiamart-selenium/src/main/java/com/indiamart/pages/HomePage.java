package com.indiamart.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * Page Object for the IndiaMart Home Page.
 *
 * Covers interactions for:
 *   TC01 – city selection + keyword search
 *   TC02 – Food, Agriculture & Farming section
 *   TC03 – clicking the Sign In button (modal handled by LoginModal)
 *   TC04 – clicking the Exporters tab (page handled by ExportersPage)
 */
public class HomePage {

    private final WebDriver driver;
    private final WebDriverWait wait;
    private final JavascriptExecutor js;

    // ── @FindBy Locators (PageFactory) ───────────────────────────────────────

    @FindBy(id = "hd_usercity")
    private WebElement cityDisplay;

    // City autocomplete suggestion – appears after typing in cityDisplay
    @FindBy(xpath = "//a[@class='ui-corner-all']")
    private WebElement cityAutoSuggest;

    @FindBy(name = "ss")
    private WebElement searchBox;

    @FindBy(linkText = "Food, Agriculture & Farming")
    private WebElement foodAgriLink;

    @FindBy(id = "user_sign_in")
    private WebElement signInButton;

    @FindBy(id = "exporters")
    private WebElement exportersTab;

    // ── Constructor ───────────────────────────────────────────────────────────

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(30));
        this.js     = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    /**
     * TC01 – Sets the location to the target city only if it is not already set.
     * Reads current city text, skips if it already matches.
     */
    public void setCity(String targetCity) {
        String currentCity = cityDisplay.getText().trim();
        if (!currentCity.equalsIgnoreCase(targetCity)) {
            cityDisplay.click();
            cityDisplay.sendKeys(targetCity);
            wait.until(ExpectedConditions.elementToBeClickable(cityAutoSuggest)).click();
        }
    }

    /**
     * TC01 – Types keyword into the search bar and submits with ENTER.
     */
    public void searchFor(String keyword) {
        searchBox.sendKeys(keyword, Keys.ENTER);
    }

    /**
     * TC02 / General – Closes the floating popup (id="idfpclose") if it appears.
     * Uses a short 5-second wait so it does not block the test if the popup is absent.
     */
    public void closePopupIfPresent() {
        try {
            WebElement popup = new WebDriverWait(driver, Duration.ofSeconds(5))
                    .until(ExpectedConditions.visibilityOfElementLocated(By.id("idfpclose")));
            js.executeScript("arguments[0].click()", popup);
        } catch (Exception ignored) {
            // Popup not present – continue normally
        }
    }

    /**
     * TC02 – Scrolls the Food, Agriculture & Farming section header into view.
     */
    public void scrollToFoodAgriSection() {
        wait.until(ExpectedConditions.visibilityOf(foodAgriLink));
        js.executeScript("arguments[0].scrollIntoView(true)", foodAgriLink);
    }

    /**
     * TC02 – Returns all sub-category / product names visible under the
     * "Food, Agriculture & Farming" section.
     *
     * XPath explanation:
     *   Find the <h2> whose text is "Food, Agriculture & Farming",
     *   then look in its following sibling divs for product-item h3 elements.
     *
     * NOTE: If names come back empty, inspect the page live and adjust the
     *       XPath selector (class names can change after a site redesign).
     */
    public List<String> getFoodAgriProductNames() {
        List<WebElement> items = driver.findElements(By.xpath(
                "//h2[normalize-space()='Food, Agriculture & Farming']" +
                "/following-sibling::div //div[contains(@class,'product-item')]//h3"));

        List<String> names = new ArrayList<>();
        for (WebElement el : items) {
            String text = el.getText().trim();
            if (!text.isEmpty()) {
                names.add(text);
            }
        }
        return names;
    }

    /**
     * TC03 – Clicks the Sign In button to open the login modal.
     */
    public void clickSignIn() {
        signInButton.click();
    }

    /**
     * TC04 – Clicks the Exporters tab to navigate to the Exporters page.
     */
    public void clickExporters() {
        exportersTab.click();
    }
}
