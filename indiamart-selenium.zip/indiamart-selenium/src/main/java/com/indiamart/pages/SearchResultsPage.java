package com.indiamart.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * Page Object for IndiaMart Search Results page.
 *
 * Handles TC01: extracting the top 3 car wash service names, URLs,
 * and ratings from the result cards.
 */
public class SearchResultsPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── XPaths ───────────────────────────────────────────────────────────────

    /**
     * The main clickable card link – getText() gives the company/service name.
     * Taken directly from the original working code.
     */
    private static final String CARD_LINK_XPATH = "//a[@class='cardlinks']";

    /**
     * Rating element XPath – relative to each card's surrounding container.
     *
     * HOW TO ADJUST IF RATINGS SHOW AS "N/A":
     *   1. Open IndiaMart in Chrome DevTools
     *   2. Search "car wash services" in Chennai
     *   3. Right-click the rating (e.g. "4.7 ★") → Inspect
     *   4. Copy the class name of the <span> and update the XPath below
     *
     * Common patterns seen on IndiaMart:
     *   .//span[contains(@class,'rat')]         ← short for "rating"
     *   .//span[contains(@class,'star')]
     *   .//div[contains(@class,'rating')]//span
     */
    private static final String RATING_SPAN_XPATH =
            ".//span[contains(@class,'rat') or contains(@class,'rating') or contains(@class,'star')]";

    // ── Constructor ───────────────────────────────────────────────────────────

    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(30));
        PageFactory.initElements(driver, this);
    }

    // ── Wait ──────────────────────────────────────────────────────────────────

    /** Waits until at least one card is visible on the results page. */
    public void waitForResults() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(CARD_LINK_XPATH)));
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    /** Returns company/service names of the top 3 result cards. */
    public List<String> getTop3ServiceNames() {
        List<WebElement> cards = driver.findElements(By.xpath(CARD_LINK_XPATH));
        List<String> names = new ArrayList<>();
        for (int i = 0; i < Math.min(3, cards.size()); i++) {
            names.add(cards.get(i).getText().trim());
        }
        return names;
    }

    /** Returns the detail-page URLs of the top 3 result cards. */
    public List<String> getTop3ServiceUrls() {
        List<WebElement> cards = driver.findElements(By.xpath(CARD_LINK_XPATH));
        List<String> urls = new ArrayList<>();
        for (int i = 0; i < Math.min(3, cards.size()); i++) {
            urls.add(cards.get(i).getAttribute("href"));
        }
        return urls;
    }

    /**
     * Attempts to extract the rating for each of the top 3 cards.
     *
     * Strategy:
     *   Walk UP from the cardlinks anchor to its nearest containing block
     *   (div/li with class containing 'bx' or 'card'), then look DOWN for
     *   a rating span.
     *
     * Falls back to "N/A" if not found, so the test does NOT fail on missing ratings.
     */
    public List<String> getTop3Ratings() {
        List<WebElement> cards = driver.findElements(By.xpath(CARD_LINK_XPATH));
        List<String> ratings = new ArrayList<>();

        for (int i = 0; i < Math.min(3, cards.size()); i++) {
            String rating = "N/A";
            try {
                // Walk up to a parent container block, then search within it
                WebElement container = cards.get(i).findElement(
                        By.xpath("./ancestor::div[contains(@class,'bx') " +
                                 "or contains(@class,'card') " +
                                 "or contains(@class,'listing')][1]"));

                WebElement ratingEl = container.findElement(By.xpath(RATING_SPAN_XPATH));
                String raw = ratingEl.getText().trim();
                if (!raw.isEmpty()) {
                    rating = raw;
                }
            } catch (NoSuchElementException | StaleElementReferenceException e) {
                // Rating not available for this listing — leave as N/A
            }
            ratings.add(rating);
        }
        return ratings;
    }
}
