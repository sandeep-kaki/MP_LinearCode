package com.indiamart.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Page Object for the IndiaMart Sign-In modal dialog.
 *
 * Handles TC03:
 *   - Entering an invalid phone number
 *   - Submitting the form
 *   - Reading the validation error message
 *   - Closing the modal
 *
 * All locators match those in the original linear code.
 */
public class LoginModal {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── @FindBy Locators ──────────────────────────────────────────────────────

    /** Phone number input field inside the sign-in modal */
    @FindBy(id = "mobile")
    private WebElement mobileInput;

    /** Error message shown below the mobile field on invalid input */
    @FindBy(id = "mobile_err")
    private WebElement mobileError;

    /** Close button (X) of the sign-in modal */
    @FindBy(id = "close_s")
    private WebElement closeButton;

    // ── Constructor ───────────────────────────────────────────────────────────

    public LoginModal(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(30));
        PageFactory.initElements(driver, this);
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    /**
     * Waits for the mobile field to appear, then types the phone number.
     * @param phoneNumber value from config.properties (e.g. "5476543218")
     */
    public void enterPhoneNumber(String phoneNumber) {
        wait.until(ExpectedConditions.visibilityOf(mobileInput));
        mobileInput.clear();
        mobileInput.sendKeys(phoneNumber);
    }

    /**
     * Submits the phone number by calling form submit.
     * Matches the original code: mobile.submit()
     */
    public void submitPhone() {
        mobileInput.submit();
    }

    /**
     * Waits for the error element to be visible, then returns its text.
     * Called AFTER submitPhone() to read the validation message.
     */
    public String getErrorMessage() {
        wait.until(ExpectedConditions.visibilityOf(mobileError));
        return mobileError.getText().trim();
    }

    /**
     * Closes the sign-in modal by clicking the X button.
     * Optional – the @After hook will quit() the driver anyway.
     */
    public void closeModal() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(closeButton)).click();
        } catch (Exception ignored) {
            // Modal may have already closed
        }
    }
}
