package com.indiamart.utils;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

/**
 * Writes car wash service data (name + rating) to an Excel file.
 *
 * Output: ./Reports/CarWashServices.xlsx
 *
 * Uses Apache POI – the same library used for Excel READING in other projects.
 * Here we use it for WRITING (output report).
 */
public class ExcelWriter {

    private static final String OUTPUT_PATH = "./Reports/CarWashServices.xlsx";

    private ExcelWriter() {}

    /**
     * Creates an .xlsx file with a header row + one data row per service.
     *
     * @param names   list of service names  (size: up to 3)
     * @param ratings list of ratings         (parallel to names)
     */
    public static void writeCarWashData(List<String> names, List<String> ratings) {

        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Car Wash Services – Chennai");

        // ── Header style ──────────────────────────────────────────────────
        CellStyle headerStyle = workbook.createCellStyle();
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setColor(IndexedColors.WHITE.getIndex());
        headerStyle.setFont(headerFont);
        headerStyle.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        // ── Header row (row 0) ────────────────────────────────────────────
        String[] headers = { "S.No", "Service Name", "Rating" };
        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }

        // ── Data rows ─────────────────────────────────────────────────────
        for (int i = 0; i < names.size(); i++) {
            Row row = sheet.createRow(i + 1);
            row.createCell(0).setCellValue(i + 1);
            row.createCell(1).setCellValue(names.get(i));
            row.createCell(2).setCellValue(ratings.isEmpty() ? "N/A" : ratings.get(i));
        }

        // ── Auto-size all columns for readability ─────────────────────────
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        // ── Ensure Reports directory exists ───────────────────────────────
        File reportsDir = new File("./Reports");
        if (!reportsDir.exists()) {
            reportsDir.mkdirs();
        }

        // ── Write to disk ─────────────────────────────────────────────────
        try (FileOutputStream fos = new FileOutputStream(OUTPUT_PATH)) {
            workbook.write(fos);
            System.out.println("  [Excel] Report saved -> " + OUTPUT_PATH);
        } catch (IOException e) {
            System.err.println("  [Excel] Failed to write: " + e.getMessage());
        } finally {
            try { workbook.close(); } catch (IOException ignored) {}
        }
    }
}
