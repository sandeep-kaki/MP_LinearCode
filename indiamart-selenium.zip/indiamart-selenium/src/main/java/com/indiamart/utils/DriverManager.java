package com.indiamart.utils;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 * DriverManager using ThreadLocal.
 *
 * WHY THREADLOCAL?
 *   Each Cucumber scenario runs in its own thread (especially with parallel runs).
 *   ThreadLocal gives each thread its own isolated WebDriver instance,
 *   preventing one scenario's driver from interfering with another.
 *
 * Lifecycle:
 *   initDriver()  → called in @Before hook (start of each scenario)
 *   getDriver()   → called by Page Objects and Step Definitions
 *   quitDriver()  → called in @After hook (end of each scenario)
 */
public class DriverManager {

    private static final ThreadLocal<WebDriver> driverThread = new ThreadLocal<>();

    private DriverManager() {}

    public static void initDriver() {
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-notifications");
        options.addArguments("--start-maximized");

        driverThread.set(new ChromeDriver(options));
    }

    public static WebDriver getDriver() {
        return driverThread.get();
    }

    public static void quitDriver() {
        WebDriver driver = driverThread.get();
        if (driver != null) {
            driver.quit();
            driverThread.remove(); // clean up to prevent memory leaks
        }
    }
}
