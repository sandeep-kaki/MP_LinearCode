package com.indiamart.utils;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;

/**
 * Utility for saving screenshots to the ./Screenshots/ directory.
 *
 * Used for INTENTIONAL screenshots (TC03, TC04) that the problem statement requires.
 * Failure screenshots (any scenario) are handled separately in the @After hook,
 * where they are attached directly to the Cucumber HTML report.
 */
public class ScreenshotUtil {

    private ScreenshotUtil() {}

    /**
     * Captures the current browser state and saves it as a PNG file.
     *
     * @param driver   active WebDriver instance
     * @param fileName file name WITHOUT extension (e.g. "invalid_number_error")
     */
    public static void take(WebDriver driver, String fileName) {
        try {
            // Ensure Screenshots directory exists
            File screenshotsDir = new File("./Screenshots");
            if (!screenshotsDir.exists()) {
                screenshotsDir.mkdirs();
            }

            File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File destination = new File("./Screenshots/" + fileName + ".png");
            FileUtils.copyFile(source, destination);

            System.out.println("  [Screenshot] Saved -> " + destination.getPath());

        } catch (IOException e) {
            System.err.println("  [Screenshot] FAILED to save screenshot: " + e.getMessage());
        }
    }
}
