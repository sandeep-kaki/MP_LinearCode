package com.indiamart.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Singleton ConfigReader.
 *
 * WHY SINGLETON?
 *   config.properties is read only once and shared across all classes.
 *   Avoids repeated file I/O on every get() call.
 *
 * Usage:
 *   ConfigReader.getInstance().get("city");
 */
public class ConfigReader {

    private static ConfigReader instance;
    private final Properties properties;

    private ConfigReader() {
        properties = new Properties();
        try (FileInputStream fis = new FileInputStream("config.properties")) {
            properties.load(fis);
        } catch (IOException e) {
            throw new RuntimeException("Cannot load config.properties – make sure it is in the project root.", e);
        }
    }

    public static ConfigReader getInstance() {
        if (instance == null) {
            instance = new ConfigReader();
        }
        return instance;
    }

    /** Returns the value for the given key. Throws clearly if the key is missing. */
    public String get(String key) {
        String value = properties.getProperty(key);
        if (value == null) {
            throw new RuntimeException("Key not found in config.properties: [" + key + "]");
        }
        return value.trim();
    }
}
