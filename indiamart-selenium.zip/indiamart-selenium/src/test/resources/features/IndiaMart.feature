Feature: IndiaMart Website Automation

  # Background runs before EVERY scenario.
  # Each scenario gets its own fresh browser session (handled by @Before hook).
  Background:
    Given I open the IndiaMart website

  # ── TC01 ──────────────────────────────────────────────────────────────
  @TC01
  Scenario: Display top 3 car wash services from Chennai
    When I set the location to the configured city
    And I search for the configured keyword
    Then the top 3 service names and ratings should be displayed and saved to Excel

  # ── TC02 ──────────────────────────────────────────────────────────────
  @TC02
  Scenario: Get product names from Food Agriculture and Farming section
    When I scroll to the Food Agriculture and Farming section
    Then all product names in that section should be displayed

  # ── TC03 ──────────────────────────────────────────────────────────────
  @TC03
  Scenario: Sign in attempt with invalid phone number
    When I open the sign in dialog
    And I enter the invalid phone number from config
    And I submit the phone number
    Then a validation error message should be displayed
    And a screenshot of the error should be saved

  # ── TC04 ──────────────────────────────────────────────────────────────
  @TC04
  Scenario: Capture top product categories from Exporters
    When I navigate to the Exporters section
    Then the top product categories from India should be displayed
    And a screenshot of the categories should be saved
