package com.indiamart.hooks;

import com.indiamart.utils.DriverManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

/**
 * Cucumber Lifecycle Hooks.
 *
 * @Before  – runs before each scenario  → initializes WebDriver
 * @After   – runs after each scenario   → attaches screenshot on failure, quits driver
 *
 * WHY SEPARATE FROM STEP DEFS?
 *   Hooks are infrastructure concerns (setup/teardown).
 *   Keeping them in their own class makes the step definitions cleaner
 *   and easier to read – they only contain business logic.
 */
public class Hooks {

    @Before
    public void setUp(Scenario scenario) {
        System.out.println("--------------------------------------------------");
        System.out.println("STARTING: " + scenario.getName());
        System.out.println("--------------------------------------------------");
        DriverManager.initDriver();
    }

    @After
    public void tearDown(Scenario scenario) {
        WebDriver driver = DriverManager.getDriver();

        // ── Attach screenshot to Cucumber HTML report on failure ──────────
        // This is SEPARATE from the intentional screenshots in TC03/TC04.
        // Those are saved to ./Screenshots/ by ScreenshotUtil.
        // This one is ONLY triggered when a scenario fails – it embeds the
        // screenshot directly into the Cucumber HTML report for easy debugging.
        if (scenario.isFailed() && driver != null) {
            byte[] screenshot = ((TakesScreenshot) driver)
                    .getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", "FAILURE: " + scenario.getName());
            System.out.println("  [Hook] Failure screenshot attached to report.");
        }

        DriverManager.quitDriver();

        System.out.println("FINISHED: " + scenario.getName()
                + "  [" + scenario.getStatus() + "]");
        System.out.println("--------------------------------------------------");
    }
}
