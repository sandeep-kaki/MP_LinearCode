package com.indiamart.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

/**
 * TestNG Runner for Cucumber.
 *
 * HOW IT WORKS:
 *   - Extends AbstractTestNGCucumberTests  → TestNG treats this as a test class
 *   - @CucumberOptions tells Cucumber where to find feature files and step defs
 *   - maven-surefire-plugin reads testng.xml, which points to this class
 *   - Result: TestNG drives execution, Cucumber provides BDD parsing
 *
 * RUN COMMANDS:
 *   All scenarios  →  mvn test
 *   Single tag     →  mvn test -Dcucumber.filter.tags="@TC01"
 *   Multiple tags  →  mvn test -Dcucumber.filter.tags="@TC01 or @TC03"
 */
@CucumberOptions(
        features  = "src/test/resources/features",
        glue      = {
                "com.indiamart.stepdefs",   // step definition classes
                "com.indiamart.hooks"       // @Before / @After hooks
        },
        plugin    = {
                "pretty",                                                    // console output
                "html:target/cucumber-reports/cucumber-report.html",         // Cucumber HTML report
                "json:target/cucumber-reports/cucumber.json"                 // JSON (for CI tools)
        },
        monochrome = true   // clean console output without ANSI color codes
)
public class TestRunner extends AbstractTestNGCucumberTests {
    // No code needed here. AbstractTestNGCucumberTests provides the @Test method
    // that iterates over all scenarios and runs them through TestNG.
}
