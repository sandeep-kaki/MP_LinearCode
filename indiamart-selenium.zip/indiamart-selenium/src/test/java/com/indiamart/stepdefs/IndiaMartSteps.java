package com.indiamart.stepdefs;

import com.indiamart.pages.ExportersPage;
import com.indiamart.pages.HomePage;
import com.indiamart.pages.LoginModal;
import com.indiamart.pages.SearchResultsPage;
import com.indiamart.utils.ConfigReader;
import com.indiamart.utils.DriverManager;
import com.indiamart.utils.ExcelWriter;
import com.indiamart.utils.ScreenshotUtil;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.util.List;

/**
 * Step Definitions for IndiaMart.feature.
 *
 * Each public method maps 1-to-1 with a Gherkin step.
 * The method annotation string must EXACTLY match the feature file wording.
 *
 * Page objects are initialized lazily (only when the relevant step runs)
 * so we don't create unnecessary page objects for scenarios that don't need them.
 */
public class IndiaMartSteps {

    // ── Shared state (within one scenario) ───────────────────────────────────
    private WebDriver driver;
    private final ConfigReader config = ConfigReader.getInstance();

    private HomePage         homePage;
    private SearchResultsPage searchResultsPage;
    private LoginModal       loginModal;
    private ExportersPage    exportersPage;

    // ═══════════════════════════════════════════════════════════════════════
    //  BACKGROUND
    // ═══════════════════════════════════════════════════════════════════════

    @Given("I open the IndiaMart website")
    public void openIndiaMart() {
        driver   = DriverManager.getDriver();         // fetched from ThreadLocal
        driver.get(config.get("baseUrl"));
        homePage = new HomePage(driver);              // initialize home page POM
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  TC01 – Top 3 Car Wash Services
    // ═══════════════════════════════════════════════════════════════════════

    @When("I set the location to the configured city")
    public void setCity() {
        homePage.setCity(config.get("city"));         // "Chennai" from config.properties
    }

    @When("I search for the configured keyword")
    public void search() {
        homePage.searchFor(config.get("searchKeyword"));    // "car wash services"
        searchResultsPage = new SearchResultsPage(driver);
        searchResultsPage.waitForResults();
    }

    @Then("the top 3 service names and ratings should be displayed and saved to Excel")
    public void displayServicesAndSaveToExcel() {
        List<String> names   = searchResultsPage.getTop3ServiceNames();
        List<String> ratings = searchResultsPage.getTop3Ratings();

        // ── Console output ────────────────────────────────────────────────
        System.out.println();
        System.out.println("====== INDIA MART - TOP 3 CAR WASH SERVICES ======");
        System.out.println("---------------------------------------------------");
        for (int i = 0; i < names.size(); i++) {
            System.out.printf("  %d. %-50s | Rating: %s%n",
                    i + 1, names.get(i), ratings.isEmpty() ? "N/A" : ratings.get(i));
        }

        // ── Write to Excel ────────────────────────────────────────────────
        ExcelWriter.writeCarWashData(names, ratings);

        // ── Assertion ─────────────────────────────────────────────────────
        Assert.assertFalse(names.isEmpty(),
                "TC01 FAILED: No car wash services were found on the results page.");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  TC02 – Food, Agriculture & Farming Section
    // ═══════════════════════════════════════════════════════════════════════

    @When("I scroll to the Food Agriculture and Farming section")
    public void scrollToFoodSection() {
        homePage.scrollToFoodAgriSection();
        homePage.closePopupIfPresent();     // dismiss popup that may cover the section
    }

    @Then("all product names in that section should be displayed")
    public void displayFoodSectionProducts() {
        List<String> products = homePage.getFoodAgriProductNames();

        // ── Console output ────────────────────────────────────────────────
        System.out.println();
        System.out.println("====== Food, Agriculture & Farming ======");
        System.out.println("-----------------------------------------");
        products.forEach(p -> System.out.println("  * " + p));

        // ── Assertion ─────────────────────────────────────────────────────
        Assert.assertFalse(products.isEmpty(),
                "TC02 FAILED: No products found in Food, Agriculture & Farming section. " +
                "Check the XPath in HomePage.getFoodAgriProductNames().");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  TC03 – Invalid Phone Number Sign-In
    // ═══════════════════════════════════════════════════════════════════════

    @When("I open the sign in dialog")
    public void openSignIn() {
        homePage.clickSignIn();
        loginModal = new LoginModal(driver);
    }

    @When("I enter the invalid phone number from config")
    public void enterInvalidPhone() {
        loginModal.enterPhoneNumber(config.get("invalidPhoneNumber"));
    }

    @When("I submit the phone number")
    public void submitPhone() {
        loginModal.submitPhone();
    }

    @Then("a validation error message should be displayed")
    public void verifyErrorMessage() {
        String errorMessage = loginModal.getErrorMessage();

        // ── Console output ────────────────────────────────────────────────
        System.out.println();
        System.out.println("====== INVALID PHONE NUMBER TEST ======");
        System.out.println("---------------------------------------");
        System.out.println("  Phone entered : " + config.get("invalidPhoneNumber"));
        System.out.println("  Error message : " + errorMessage);

        // ── Assertion ─────────────────────────────────────────────────────
        Assert.assertFalse(errorMessage.isEmpty(),
                "TC03 FAILED: Expected a validation error for invalid phone, but none appeared.");
    }

    @Then("a screenshot of the error should be saved")
    public void screenshotError() {
        ScreenshotUtil.take(driver, "invalid_number_error");
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  TC04 – Top Product Categories from Exporters
    // ═══════════════════════════════════════════════════════════════════════

    @When("I navigate to the Exporters section")
    public void goToExporters() {
        homePage.clickExporters();
        exportersPage = new ExportersPage(driver);
        exportersPage.waitForPage();
    }

    @Then("the top product categories from India should be displayed")
    public void displayTopCategories() {
        String title             = exportersPage.getSectionTitle();
        List<String> categories  = exportersPage.getTopProductCategories();

        // ── Console output ────────────────────────────────────────────────
        System.out.println();
        System.out.println("====== " + title + " ======");
        System.out.println("---------------------------------------------------");
        categories.forEach(c -> System.out.println("  * " + c));

        // ── Assertion ─────────────────────────────────────────────────────
        Assert.assertFalse(categories.isEmpty(),
                "TC04 FAILED: No top product categories found. " +
                "Check the XPath in ExportersPage.getTopProductCategories().");
    }

    @And("a screenshot of the categories should be saved")
    public void screenshotCategories() {
        exportersPage.scrollToTopCategories();   // scroll section into view first
        ScreenshotUtil.take(driver, "top_product_categories_india");
    }
}
