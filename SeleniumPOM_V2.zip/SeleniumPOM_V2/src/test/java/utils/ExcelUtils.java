//package utils;
//
//import org.apache.poi.ss.usermodel.Cell;
//import org.apache.poi.ss.usermodel.CellType;
//import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.ss.usermodel.Workbook;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.util.HashMap;
//import java.util.Map;
//
///**
// * ExcelUtils — reads data from an .xlsx file using Apache POI.
// *
// * How it works:
// *   - Row 1  = Column headers  (e.g. FullName, Email, Country ...)
// *   - Row 2+ = Actual test data
// *
// * Usage:
// *   ExcelUtils excel = new ExcelUtils("testdata/TestData.xlsx", "ContactFormData");
// *   String name = excel.getData(2, "FullName");   // row 2, column "FullName"
// */
//public class ExcelUtils {
//
//    private Sheet sheet;
//
//    // ---------------------------------------------------------------
//    // Constructor — opens the file and selects the sheet
//    // ---------------------------------------------------------------
//    public ExcelUtils(String filePath, String sheetName) throws IOException {
//        FileInputStream fis = new FileInputStream(filePath);
//        Workbook workbook   = new XSSFWorkbook(fis);
//        sheet               = workbook.getSheet(sheetName);
//
//        if (sheet == null) {
//            throw new RuntimeException("Sheet '" + sheetName + "' not found in " + filePath);
//        }
//        System.out.println("Excel loaded: " + filePath + " | Sheet: " + sheetName);
//    }
//
//    // ---------------------------------------------------------------
//    // getData(rowNumber, columnHeader)
//    //   rowNumber  — 1-based (row 1 = headers, row 2 = first data row)
//    //   columnHeader — exact header name from row 1
//    // ---------------------------------------------------------------
//    public String getData(int rowNumber, String columnHeader) {
//
//        // Step 1: Find column index by matching header name
//        Row headerRow = sheet.getRow(0); // Row 1 in Excel = index 0
//        int columnIndex = -1;
//
//        for (int i = 0; i < headerRow.getLastCellNum(); i++) {
//            String header = headerRow.getCell(i).getStringCellValue().trim();
//            if (header.equalsIgnoreCase(columnHeader)) {
//                columnIndex = i;
//                break;
//            }
//        }
//
//        if (columnIndex == -1) {
//            throw new RuntimeException("Column header '" + columnHeader + "' not found in Excel sheet.");
//        }
//
//        // Step 2: Get the cell value from the requested row
//        Row dataRow = sheet.getRow(rowNumber - 1); // convert 1-based to 0-based
//        if (dataRow == null) {
//            throw new RuntimeException("Row " + rowNumber + " not found in Excel sheet.");
//        }
//
//        Cell cell = dataRow.getCell(columnIndex);
//        if (cell == null) {
//            return ""; // empty cell
//        }
//
//        // Step 3: Return value based on cell type
//        if (cell.getCellType() == CellType.NUMERIC) {
//            // Avoid returning "1.23456789E9" for phone numbers
//            return String.valueOf((long) cell.getNumericCellValue());
//        } else {
//            return cell.getStringCellValue().trim();
//        }
//    }
//
//    // ---------------------------------------------------------------
//    // getRowCount() — returns total number of data rows (excludes header)
//    // ---------------------------------------------------------------
//    public int getRowCount() {
//        return sheet.getLastRowNum(); // lastRowNum is 0-based, so this = data rows count
//    }
//}

package utils;

import org.apache.poi.ss.usermodel.*;
import java.io.FileInputStream;
import java.io.IOException;

public class ExcelUtils {

    private Sheet sheet;

    public ExcelUtils(String filePath, String sheetName) throws IOException {
        FileInputStream fis = new FileInputStream(filePath);
        Workbook wb = WorkbookFactory.create(fis);
        sheet = wb.getSheet(sheetName);
        fis.close();
    }

    // Read cell by column name (header row = 1st row)
    public String getData(int rowNumber, String columnName) {

        // Header row
        Row headerRow = sheet.getRow(0);

        int colIndex = -1;
        for (int c = 0; c < headerRow.getLastCellNum(); c++) {
            if (headerRow.getCell(c).getStringCellValue().equalsIgnoreCase(columnName)) {
                colIndex = c;
                break;
            }
        }

        if (colIndex == -1) {
            throw new RuntimeException("Column not found: " + columnName);
        }

        Row row = sheet.getRow(rowNumber - 1); // Your code uses row=2 meaning index=1
        Cell cell = row.getCell(colIndex);

        DataFormatter formatter = new DataFormatter();
        return formatter.formatCellValue(cell).trim();
    }
}
