package learnSelenium.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseTest {

    public WebDriver driver;

    @BeforeMethod
    public void setUp() {
        // Selenium 4 auto-manages ChromeDriver — no System.setProperty needed
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        System.out.println("===== Browser launched =====");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            System.out.println("===== Browser closed =====");
        }
    }
}
