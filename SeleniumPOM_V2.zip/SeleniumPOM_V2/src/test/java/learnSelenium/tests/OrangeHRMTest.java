package learnSelenium.tests;

import learnSelenium.base.BaseTest;
import learnSelenium.pages.ContactSalesPage;
import learnSelenium.pages.GooglePage;
import learnSelenium.pages.OrangeHRMHomePage;
import learnSelenium.utils.ExcelUtils;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;

public class OrangeHRMTest extends BaseTest {

    // ---------------------------------------------------------------
    // ExcelUtils instance — reads from testdata/TestData.xlsx
    // ---------------------------------------------------------------
    private ExcelUtils excel;

    @BeforeClass
    public void loadExcel() throws IOException {
        excel = new ExcelUtils("testdata/TestData.xlsx", "ContactFormData");
        System.out.println("===== Test data loaded from Excel =====");
    }

    // ---------------------------------------------------------------
    // @Test — reads all data from Excel row 2
    // ---------------------------------------------------------------
    @Test
    public void submitOrangeHRMContactForm() throws InterruptedException, IOException {

        // ---- Read all data from Excel (Row 2 = first data row) ----
        String searchKeyword = excel.getData(2, "SearchKeyword");
        String fullName      = excel.getData(2, "FullName");
        String contact       = excel.getData(2, "Contact");
        String jobTitle      = excel.getData(2, "JobTitle");
        String country       = excel.getData(2, "Country");
        String employees     = excel.getData(2, "NoOfEmployees");
        String email         = excel.getData(2, "Email");
        String companyName   = excel.getData(2, "CompanyName");
        String comment       = excel.getData(2, "Comment");

        System.out.println("===== Data read from Excel =====");
        System.out.println("Name: " + fullName + " | Email: " + email + " | Country: " + country);

        // ==============================================
        // STEP 1 — Google Search
        // ==============================================
        GooglePage googlePage = new GooglePage(driver);
        googlePage.goTo();
        googlePage.searchFor(searchKeyword);
        googlePage.waitForSearchResults();
        Thread.sleep(2000);

        googlePage.navigateBackTwice();
        Thread.sleep(2000);

        googlePage.navigateForward();
        Thread.sleep(1000);

        // ==============================================
        // STEP 2 — OrangeHRM Home Page
        // ==============================================
        OrangeHRMHomePage homePage = new OrangeHRMHomePage(driver);
        homePage.openInNewTab();
        homePage.clickContactSales();

        // ==============================================
        // STEP 3 — Fill Contact Sales Form
        // ==============================================
        ContactSalesPage contactPage = new ContactSalesPage(driver);

        contactPage.fillForm(fullName, contact, jobTitle, country, employees, email, companyName);

        contactPage.acceptCookies();

        // CAPTCHA 1 — 80 seconds to solve manually in browser
        contactPage.solveCaptchaAndWait(80);

        contactPage.takeScreenshot("screenshot.png");

        contactPage.submitFirstForm();

        // CAPTCHA 2 — 40 seconds to solve manually in browser
        contactPage.fillComment(comment);
        contactPage.solveCaptchaAndWait(40);

        contactPage.submitSecondForm();

        Thread.sleep(2000);
        System.out.println("===== Test completed successfully =====");
    }
}
