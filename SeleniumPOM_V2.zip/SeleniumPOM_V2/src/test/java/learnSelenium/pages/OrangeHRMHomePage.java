package learnSelenium.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class OrangeHRMHomePage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ---------------------------------------------------------------
    // @FindBy — PageFactory annotations
    // ---------------------------------------------------------------
    @FindBy(linkText = "Contact Sales")
    private WebElement contactSalesLink;

    // ---------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------
    public OrangeHRMHomePage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(30));
        PageFactory.initElements(driver, this);  // ← PageFactory
    }

    // ---------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------

    public void openInNewTab() {
        driver.switchTo().newWindow(WindowType.TAB);
        driver.navigate().to("https://www.orangehrm.com/");
        System.out.println("Opened OrangeHRM in new tab");
    }

    public void clickContactSales() {
        wait.until(ExpectedConditions.elementToBeClickable(contactSalesLink)).click();
        System.out.println("Clicked Contact Sales");
    }
}
