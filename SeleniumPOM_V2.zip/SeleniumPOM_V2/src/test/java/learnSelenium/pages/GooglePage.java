package learnSelenium.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class GooglePage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ---------------------------------------------------------------
    // @FindBy — PageFactory annotations replace By locators
    // ---------------------------------------------------------------
    @FindBy(name = "q")
    private WebElement searchBox;

    @FindBy(id = "search")
    private WebElement searchResults;

    // ---------------------------------------------------------------
    // Constructor — PageFactory.initElements wires @FindBy to elements
    // ---------------------------------------------------------------
    public GooglePage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(30));
        PageFactory.initElements(driver, this);  // ← This is PageFactory
    }

    // ---------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------

    public void goTo() {
        driver.get("https://google.com/");
        System.out.println("Opened Google");
    }

    public void searchFor(String text) {
        wait.until(ExpectedConditions.visibilityOf(searchBox));
        searchBox.sendKeys(text, Keys.ENTER);
        System.out.println("Searched for: " + text);
    }

    public void waitForSearchResults() {
        wait.until(ExpectedConditions.visibilityOf(searchResults));
        System.out.println("Search results displayed");
    }

    public void navigateBackTwice() throws InterruptedException {
        driver.navigate().back();
        Thread.sleep(1000);
        driver.navigate().back();
        System.out.println("Navigated back twice. URL: " + driver.getCurrentUrl());
    }

    public void navigateForward() {
        driver.navigate().forward();
        wait.until(ExpectedConditions.visibilityOf(searchResults));
        System.out.println("Navigated forward. URL: " + driver.getCurrentUrl());
    }
}
