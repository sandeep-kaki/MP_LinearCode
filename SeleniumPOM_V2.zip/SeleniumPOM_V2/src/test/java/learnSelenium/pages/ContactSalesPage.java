package learnSelenium.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Duration;

public class ContactSalesPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ---------------------------------------------------------------
    // @FindBy — PageFactory annotations
    // Note: iframes and dropdowns needing Select still use By separately
    // ---------------------------------------------------------------
    @FindBy(name = "FullName")
    private WebElement fullNameField;

    @FindBy(name = "Contact")
    private WebElement contactField;

    @FindBy(name = "JobTitle")
    private WebElement jobTitleField;

    @FindBy(name = "Country")
    private WebElement countryDropdown;

    @FindBy(name = "NoOfEmployees")
    private WebElement employeesDropdown;

    @FindBy(name = "Email")
    private WebElement emailField;

    @FindBy(className = "textarea")
    private WebElement textAreaField;

    @FindBy(name = "CompanyName")
    private WebElement companyNameField;

    @FindBy(id = "CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll")
    private WebElement cookieButton;

    @FindBy(id = "Form_getForm_action_submitForm")
    private WebElement submitButton1;

    @FindBy(name = "Comment")
    private WebElement commentField;

    @FindBy(name = "action_submitForm")
    private WebElement submitButton2;

    // iframes cannot use @FindBy for switchTo — kept as By locators
    private final By captchaFrame    = By.cssSelector("iframe[title='reCAPTCHA']");
    private final By captchaCheckbox = By.id("recaptcha-anchor");

    // ---------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------
    public ContactSalesPage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(30));
        PageFactory.initElements(driver, this);  // ← PageFactory
    }

    // ---------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------

    public void fillForm(String fullName, String contact, String jobTitle,
                         String country, String employees, String email, String company) {

        wait.until(ExpectedConditions.visibilityOf(fullNameField)).sendKeys(fullName);
        contactField.sendKeys(contact);
        jobTitleField.sendKeys(jobTitle);

        new Select(countryDropdown).selectByVisibleText(country);
        new Select(employeesDropdown).selectByVisibleText(employees);

        emailField.sendKeys(email);
        textAreaField.click();
        companyNameField.sendKeys(company);

        System.out.println("Form filled successfully");
    }

    public void acceptCookies() throws InterruptedException {
        Thread.sleep(5000); // wait for cookie banner to appear
        cookieButton.click();
        System.out.println("Accepted cookies");
    }

    public void solveCaptchaAndWait(int waitSeconds) throws InterruptedException {
        // iframes need driver.switchTo() — PageFactory elements don't work inside frames
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(captchaFrame));
        WebElement checkbox = wait.until(ExpectedConditions.elementToBeClickable(captchaCheckbox));
        checkbox.click();
        driver.switchTo().defaultContent();
        System.out.println("Clicked CAPTCHA. Waiting " + waitSeconds + "s for manual solve...");
        Thread.sleep(waitSeconds * 1000L);
    }

    public void takeScreenshot(String fileName) throws IOException {
        TakesScreenshot ts = (TakesScreenshot) driver;
        File src = ts.getScreenshotAs(OutputType.FILE);
        Path dir = Paths.get("screenshots");
        Files.createDirectories(dir);
        Path target = dir.resolve(fileName);
        Files.copy(src.toPath(), target, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Screenshot saved: " + target.toAbsolutePath());
    }

    public void submitFirstForm() {
        submitButton1.submit();
        System.out.println("First form submitted");
    }

    public void fillComment(String comment) {
        commentField.sendKeys(comment);
        System.out.println("Comment filled: " + comment);
    }

    public void submitSecondForm() {
        submitButton2.submit();
        System.out.println("Second form submitted");
    }
}
