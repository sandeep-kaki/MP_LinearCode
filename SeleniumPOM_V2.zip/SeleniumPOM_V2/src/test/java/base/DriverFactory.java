package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class DriverFactory {

    public static WebDriver getDriver(String browserName) {

        if (browserName == null) {
            browserName = "chrome";   // default
        }

        switch (browserName.toLowerCase()) {

            case "edge":
                return new EdgeDriver();

            case "chrome":
            default:
                return new ChromeDriver();
        }
    }
}