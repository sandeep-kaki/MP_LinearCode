package base;

import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseTest {

    public WebDriver driver;

    @BeforeMethod
    public void setUp() {

        String browser = System.getProperty("browser", "chrome"); 
        driver = DriverFactory.getDriver(browser);

        driver.manage().window().maximize();
        System.out.println("===== Browser launched: " + browser + " =====");
    }

    

    @AfterMethod
    public void tearDown() throws InterruptedException {
        if (driver != null) {
            driver.close();
            Thread.sleep(2000);            
            System.out.println("===== Current Browser closed =====");
            driver.quit();
            System.out.println("===== Browser closed =====");
    
        }
    }
}
