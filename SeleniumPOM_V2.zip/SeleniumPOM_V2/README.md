# Selenium POM V2 — PageFactory + Apache POI Excel

## What's New in V2
- All locators use `@FindBy` annotations (PageFactory style)
- `PageFactory.initElements(driver, this)` in every Page class constructor
- Test data is read from `testdata/TestData.xlsx` via Apache POI
- `ExcelUtils.java` — reusable utility to read any cell by row + column header name

## Project Structure
```
SeleniumPOM_V2/
├── pom.xml                          ← Maven: Selenium + TestNG + Apache POI
├── testng.xml                       ← TestNG suite runner
├── testdata/
│   └── TestData.xlsx                ← Edit this to change test inputs
├── screenshots/                     ← Screenshots saved here at runtime
└── src/test/java/learnSelenium/
    ├── base/
    │   └── BaseTest.java            ← @BeforeMethod / @AfterMethod (browser open/close)
    ├── utils/
    │   └── ExcelUtils.java          ← Apache POI Excel reader utility
    ├── pages/
    │   ├── GooglePage.java          ← @FindBy + PageFactory
    │   ├── OrangeHRMHomePage.java   ← @FindBy + PageFactory
    │   └── ContactSalesPage.java    ← @FindBy + PageFactory
    └── tests/
        └── OrangeHRMTest.java       ← @Test reads from Excel, calls page methods
```

## How to Run

### Eclipse
1. File → Import → Existing Maven Projects → select `SeleniumPOM_V2` folder
2. Maven will download all dependencies automatically
3. Right-click `testng.xml` → Run As → TestNG Suite

### IntelliJ
1. File → Open → select `SeleniumPOM_V2` folder
2. Right-click `testng.xml` → Run

### Maven command
```
mvn test
```

## Editing Test Data
Open `testdata/TestData.xlsx` and update Row 2 values.
Column headers must NOT be changed (they match the Java code exactly):

| FullName | Contact | JobTitle | Country | NoOfEmployees | Email | CompanyName | Comment | SearchKeyword |

## CAPTCHA Note
Two CAPTCHAs appear during the test. The test pauses and waits:
- First CAPTCHA  → 80 seconds to solve manually in the Chrome window
- Second CAPTCHA → 40 seconds to solve manually in the Chrome window

## PageFactory — Quick Explanation
| Old way (By)                              | New way (PageFactory)                      |
|-------------------------------------------|--------------------------------------------|
| `private By nameField = By.name("x");`    | `@FindBy(name = "x")`                      |
| `driver.findElement(nameField).sendKeys()`| `nameField.sendKeys()`  (direct use)       |
| No init needed                            | `PageFactory.initElements(driver, this);`  |
