package Tests;

import Base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SearchResultsPage;

/**
 * TC001 - Flipkart Mobile Search & Validation Test
 *
 * Steps:
 *  1. Open Flipkart in browser (Chrome / Edge / Firefox)
 *  2. Close login popup
 *  3. Search "mobiles" and select "mobiles under 15000" from suggestions
 *  4. Drag price slider to set max price ~10,000
 *  5. Select OS version filter: "Pie"
 *  6. Sort by "Newest First"
 *  7. Print top 5 mobile names and prices
 *  8. Assert first mobile price is less than Rs. 30,000
 *  9. Close browser
 */
public class FlipkartMobileSearchTest extends BaseTest {

    private HomePage homePage;
    private SearchResultsPage searchResultsPage;

    @BeforeMethod
    @Parameters("browser")
    public void setUp(@Optional("chrome") String browser) {
        driver = initializeDriver(browser);
        homePage = new HomePage(driver);
        searchResultsPage = new SearchResultsPage(driver);
        System.out.println("LOG: Browser launched - " + browser);
    }

    @Test
    public void TC001_MobileSearchAndPriceValidation() {

        System.out.println(">>> TC001 STARTED: Mobile Search & Price Validation");

        // Step 1: Close login popup
        homePage.closeLoginPopup();

        // Step 2: Search for "mobiles" and pick "mobiles under 15000" from dropdown
        homePage.enterSearchText("mobiles");
        homePage.selectSuggestionContaining("under 15000");

        // Step 3: Drag price slider to reduce max price to ~10,000
        searchResultsPage.dragPriceSliderToReduce();

        // Step 4: Select OS version "Pie" from filters
        searchResultsPage.selectOperatingSystem("Pie");

        // Step 5: Sort by Newest First
        searchResultsPage.sortByNewestFirst();

        // Step 6: Print top 5 mobiles (name + price)
        String[] topMobile = searchResultsPage.getTop5MobileData();
        String topMobileName  = topMobile[0];
        String topMobilePrice = topMobile[1];

        System.out.println(">>> First Mobile: " + topMobileName);
        System.out.println(">>> First Price : " + topMobilePrice);

        // Step 7: Assert first mobile price < Rs. 30,000
        int priceInt = Integer.parseInt(topMobilePrice.replaceAll("[^0-9]", ""));
        System.out.println(">>> Parsed Price (int): " + priceInt);

        Assert.assertTrue(
                priceInt < 30000,
                "FAIL: First mobile price (" + priceInt + ") is NOT less than 30,000!"
        );

        System.out.println(">>> TC001 PASSED: Price is Rs." + priceInt + " which is less than Rs.30,000");
    }

    @AfterMethod
    public void tearDownTest() {
        tearDown();
    }
}
