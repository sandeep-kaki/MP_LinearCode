package Base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

public class BaseTest {

    public WebDriver driver;
    public Properties prop;

    public WebDriver getDriver() {
        return this.driver;
    }

    /**
     * Initializes the WebDriver based on browser name passed from TestNG XML.
     */
    public WebDriver initializeDriver(String browser) {

        switch (browser.toLowerCase()) {

            case "chrome":
                WebDriverManager.chromedriver().setup();
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.addArguments("--remote-allow-origins=*");
                chromeOptions.addArguments("--log-level=3");
                chromeOptions.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
                driver = new ChromeDriver(chromeOptions);
                break;

            case "edge":
                try {
                    WebDriverManager.edgedriver().setup();
                } catch (Exception e) {
                    System.out.println("WebDriverManager failed for Edge, trying manual path...");
                    System.setProperty("webdriver.edge.driver", "C:\\BrowserDriver\\edgedriver_win64\\msedgedriver.exe");
                }
                EdgeOptions edgeOptions = new EdgeOptions();
                edgeOptions.addArguments("--remote-allow-origins=*");
                driver = new EdgeDriver(edgeOptions);
                break;

            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
                break;

            default:
                throw new IllegalArgumentException("Browser not supported: " + browser);
        }

        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.get(getBaseUrl());

        return driver;
    }

    public String getBaseUrl() {
        prop = new Properties();
        try {
            String configPath = System.getProperty("user.dir") + "/src/main/java/utils/config.properties";
            FileInputStream fis = new FileInputStream(configPath);
            prop.load(fis);
        } catch (IOException e) {
            System.out.println("LOG: config.properties not found at: " + System.getProperty("user.dir"));
        }
        return prop.getProperty("url");
    }

    public void tearDown() {
        if (driver != null) {
            driver.quit();
            System.out.println("LOG: Browser closed successfully.");
        }
    }
}
