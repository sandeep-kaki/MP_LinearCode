package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

public class WaitHelper {

    WebDriver driver;
    Wait<WebDriver> myWait;

    public WaitHelper(WebDriver driver) {
        this.driver = driver;
        myWait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(15))
                .pollingEvery(Duration.ofMillis(500))
                .ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class)
                .withMessage("Element not found - fluent wait timed out");
    }

    public void waitUntilElementToBeClickable(WebElement element) {
        myWait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public WebElement waitUntilElementToBeClickable(By locator) {
        return myWait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    public void waitUntilVisibilityOfAllElements(List<WebElement> elements) {
        myWait.until(ExpectedConditions.refreshed(
                ExpectedConditions.visibilityOfAllElements(elements)
        ));
    }

    public void waitUntilElementToBeclickbleForSpecificTime(WebElement element, int timeoutInSeconds) {
        WebDriverWait customWait = new WebDriverWait(driver, Duration.ofSeconds(timeoutInSeconds));
        customWait.until(ExpectedConditions.elementToBeClickable(element));
    }
}
