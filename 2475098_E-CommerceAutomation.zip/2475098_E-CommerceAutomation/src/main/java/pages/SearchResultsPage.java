package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.WaitHelper;

import java.util.List;

/**
 * Page Object for Flipkart Search Results Page.
 * Handles: price slider, OS filter, sort order, and reading product data.
 */
public class SearchResultsPage {

    private WebDriver driver;
    private Actions actions;
    private JavascriptExecutor jse;
    private WaitHelper waitHelper;

    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
        this.actions = new Actions(driver);
        this.jse = (JavascriptExecutor) driver;
        this.waitHelper = new WaitHelper(driver);
        PageFactory.initElements(driver, this);
    }

    // --- Locators ---

    // Right handle of the price range slider
    @FindBy(xpath = "(//div[@class='G12X4V'])[2]")
    WebElement rightPriceSlider;

    // "Operating System Version Name" filter section header
    @FindBy(xpath = "//section[@class='KNnSWQ vRd1kF']//div[text()='Operating System Version Name']")
    WebElement operatingSystemSectionHeader;

    // "More" button inside the OS section (if needed to expand)
    @FindBy(xpath = "//section[@class='KNnSWQ vRd1kF']//div[text()='Operating System Version Name']/following::div[@class='GN2Hca rQQNAD']")
    WebElement moreButton;

    // "Newest First" sort button
    @FindBy(xpath = "//div[contains(@class, 's6YJlm')]//div[normalize-space()='Newest First']")
    WebElement newestFirstBtn;

    // Dynamic locators for product list
    By productNamesLocator = By.className("RG5Slk");
    By productPricesLocator = By.cssSelector(".hZ3P6w.DeU9vF");

    // --- Helper Methods ---

    private void jsScrollAndClick(WebElement element) {
        jse.executeScript("arguments[0].scrollIntoView({block:'center'})", element);
        jse.executeScript("arguments[0].click();", element);
    }

    // --- Page Actions ---

    /**
     * Drags the right handle of the price slider to the left to reduce max price.
     * The offset (-180) approximates reducing the price to around 10,000.
     */
    public void dragPriceSliderToReduce() {
        waitHelper.waitUntilElementToBeClickable(rightPriceSlider);
        jse.executeScript("arguments[0].scrollIntoView({block:'center'})", rightPriceSlider);
        actions.dragAndDropBy(rightPriceSlider, -180, 0).build().perform();
        System.out.println("LOG: Price slider dragged to reduce max price.");
    }

    /**
     * Selects the given OS version name from the filter section.
     * Expands the 'More' list if the option is not immediately visible.
     */
    public void selectOperatingSystem(String osName) {
        try {
            Thread.sleep(1000); // allow filters to settle
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Expand OS section
        jsScrollAndClick(operatingSystemSectionHeader);
        System.out.println("LOG: OS filter section expanded.");

        // Build dynamic XPath for the OS option
        String osXPath = "//section[@class='KNnSWQ vRd1kF']" +
                "//div[text()='Operating System Version Name']" +
                "/following::div[text()='" + osName + "']";

        List<WebElement> osOptions = driver.findElements(By.xpath(osXPath));

        // If not visible, click the "More" button to expand
        if (osOptions.isEmpty()) {
            try {
                waitHelper.waitUntilElementToBeclickbleForSpecificTime(moreButton, 3);
                jsScrollAndClick(moreButton);
                System.out.println("LOG: Clicked 'More' to expand OS options.");
            } catch (Exception e) {
                System.out.println("LOG: 'More' button not available for this search.");
            }
        }

        // Click the checkbox for the OS
        String checkboxXPath = osXPath + "/preceding-sibling::div";
        WebElement osCheckbox = waitHelper.waitUntilElementToBeClickable(By.xpath(checkboxXPath));
        jsScrollAndClick(osCheckbox);
        System.out.println("LOG: OS filter selected: " + osName);
    }

    /**
     * Clicks 'Newest First' to sort results by newest arrivals.
     */
    public void sortByNewestFirst() {
        waitHelper.waitUntilElementToBeClickable(newestFirstBtn);
        jsScrollAndClick(newestFirstBtn);
        System.out.println("LOG: Sorted by 'Newest First'.");
    }

    /**
     * Reads the top 5 product names and prices from the results list.
     * Prints each to console and returns the first product's [name, price].
     */
    public String[] getTop5MobileData() {
        try {
            Thread.sleep(2000); // wait for results to refresh after sort
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        List<WebElement> names  = driver.findElements(productNamesLocator);
        List<WebElement> prices = driver.findElements(productPricesLocator);

        int count = Math.min(5, Math.min(names.size(), prices.size()));

        System.out.println("\n========== TOP 5 MOBILE RESULTS ==========");
        for (int i = 0; i < count; i++) {
            System.out.printf("%d. %-60s | %s%n",
                    (i + 1), names.get(i).getText(), prices.get(i).getText());
        }
        System.out.println("==========================================\n");

        if (!names.isEmpty() && !prices.isEmpty()) {
            return new String[]{names.get(0).getText(), prices.get(0).getText()};
        } else {
            System.out.println("ERROR: Product list was empty.");
            return new String[]{"NOT FOUND", "NOT FOUND"};
        }
    }
}
