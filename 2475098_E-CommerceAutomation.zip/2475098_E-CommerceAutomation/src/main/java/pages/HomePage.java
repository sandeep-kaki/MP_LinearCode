package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.WaitHelper;

import java.util.List;

/**
 * Page Object for Flipkart Home Page.
 * Handles: popup close, search bar, and dropdown suggestion selection.
 */
public class HomePage {

    WebDriver driver;
    WaitHelper waitHelper;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.waitHelper = new WaitHelper(driver);
        PageFactory.initElements(driver, this);
    }

    // --- Locators ---

    // Login popup close button
    @FindBy(className = "b3wTlE")
    WebElement loginCloseButton;

    // Search bar
    @FindBy(name = "q")
    WebElement searchBar;

    // Auto-suggestion dropdown items
    @FindBy(css = "ul.VCplLH div.VDtK0l")
    List<WebElement> searchSuggestions;

    // --- Actions ---

    /**
     * Closes the login popup if it appears.
     */
    public void closeLoginPopup() {
        try {
            waitHelper.waitUntilElementToBeClickable(loginCloseButton);
            loginCloseButton.click();
            System.out.println("LOG: Login popup closed.");
        } catch (Exception e) {
            System.out.println("LOG: No login popup found, continuing...");
        }
    }

    /**
     * Types the given text into the search bar.
     */
    public void enterSearchText(String searchText) {
        waitHelper.waitUntilElementToBeClickable(searchBar);
        searchBar.sendKeys(searchText);
        System.out.println("LOG: Typed into search bar: " + searchText);
    }

    /**
     * Clicks the dropdown suggestion that contains the given partial text.
     * Example: partialText = "under 15000" will match "mobiles under 15000"
     */
    public void selectSuggestionContaining(String partialText) {
        waitHelper.waitUntilVisibilityOfAllElements(searchSuggestions);
        for (WebElement suggestion : searchSuggestions) {
            String text = suggestion.getText().toLowerCase();
            System.out.println("LOG: Suggestion found: " + text);
            if (text.contains(partialText.toLowerCase())) {
                suggestion.click();
                System.out.println("LOG: Clicked suggestion: " + text);
                return;
            }
        }
        System.out.println("WARNING: No suggestion matched: " + partialText);
    }
}
