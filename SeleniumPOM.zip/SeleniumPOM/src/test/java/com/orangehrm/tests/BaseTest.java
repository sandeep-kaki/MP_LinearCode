package com.orangehrm.tests;

import com.orangehrm.pages.LoginPage;
import com.orangehrm.pages.DashboardPage;
import com.orangehrm.utils.DriverManager;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BaseTest {

    protected WebDriver driver;
    protected LoginPage loginPage;
    protected DashboardPage dashboardPage;

    protected static final String BASE_URL =
        "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";

    protected static final String ADMIN_USER = "Admin";
    protected static final String ADMIN_PASS = "admin123";

    @BeforeClass
    public void setUp() {
        driver = DriverManager.getDriver();
        driver.get(BASE_URL);
        loginPage = new LoginPage(driver);
    }

    @AfterClass
    public void tearDown() {
        DriverManager.quitDriver();
    }
}
