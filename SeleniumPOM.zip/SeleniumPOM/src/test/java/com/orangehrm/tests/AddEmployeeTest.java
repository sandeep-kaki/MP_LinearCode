package com.orangehrm.tests;

import com.orangehrm.pages.AddEmployeePage;
import com.orangehrm.pages.DashboardPage;
import com.orangehrm.utils.ExcelUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

public class AddEmployeeTest extends BaseTest {

    private AddEmployeePage addEmployeePage;

    // Path to the Excel test data file
    private static final String EXCEL_FILE =
        System.getProperty("user.dir") + File.separator +
        "src" + File.separator + "test" + File.separator +
        "resources" + File.separator + "TestData.xlsx";

    private static final String SHEET_NAME = "EmployeeData";

    @BeforeClass(alwaysRun = true)
    @Override
    public void setUp() {
        super.setUp();
        // Log in first so both @Test methods start from Dashboard
        dashboardPage = loginPage.login(ADMIN_USER, ADMIN_PASS);
        addEmployeePage = new AddEmployeePage(driver);
    }

    /**
     * Test 3: Add the first employee from the Excel sheet.
     */
    @Test(priority = 1, description = "Add first employee using data from Excel (Row 1)")
    public void testAddEmployeeRow1() throws IOException {
        System.out.println("=== TEST: testAddEmployeeRow1 ===");

        ExcelUtils.setExcelFile(EXCEL_FILE, SHEET_NAME);

        // Row 0 = header  →  Row 1 = first data row
        String firstName    = ExcelUtils.getCellData(1, 0);
        String middleName   = ExcelUtils.getCellData(1, 1);
        String lastName     = ExcelUtils.getCellData(1, 2);
        String loginUser    = ExcelUtils.getCellData(1, 3);
        String password     = ExcelUtils.getCellData(1, 4);
        String nationality  = ExcelUtils.getCellData(1, 5);
        String maritalStatus= ExcelUtils.getCellData(1, 6);

        ExcelUtils.closeWorkbook();

        System.out.println("Adding employee: " + firstName + " " + middleName + " " + lastName);

        addEmployeePage.fillAndSaveEmployee(
            firstName, middleName, lastName,
            loginUser, password,
            nationality, maritalStatus
        );

        // After save, URL should move away from addEmployee
        String currentUrl = driver.getCurrentUrl();
        Assert.assertFalse(currentUrl.contains("addEmployee"),
            "URL should change from addEmployee after saving. Actual: " + currentUrl);

        System.out.println("Employee 1 added successfully.");
    }

    /**
     * Test 4: Add the second employee from the Excel sheet.
     */
    @Test(priority = 2, description = "Add second employee using data from Excel (Row 2)",
          dependsOnMethods = "testAddEmployeeRow1")
    public void testAddEmployeeRow2() throws IOException {
        System.out.println("=== TEST: testAddEmployeeRow2 ===");

        // Navigate back to add employee page
        driver.get("https://opensource-demo.orangehrmlive.com" +
                   "/web/index.php/pim/addEmployee");

        ExcelUtils.setExcelFile(EXCEL_FILE, SHEET_NAME);

        // Row 2 = second data row
        String firstName    = ExcelUtils.getCellData(2, 0);
        String middleName   = ExcelUtils.getCellData(2, 1);
        String lastName     = ExcelUtils.getCellData(2, 2);
        String loginUser    = ExcelUtils.getCellData(2, 3);
        String password     = ExcelUtils.getCellData(2, 4);
        String nationality  = ExcelUtils.getCellData(2, 5);
        String maritalStatus= ExcelUtils.getCellData(2, 6);

        ExcelUtils.closeWorkbook();

        System.out.println("Adding employee: " + firstName + " " + middleName + " " + lastName);

        addEmployeePage.fillAndSaveEmployee(
            firstName, middleName, lastName,
            loginUser, password,
            nationality, maritalStatus
        );

        String currentUrl = driver.getCurrentUrl();
        Assert.assertFalse(currentUrl.contains("addEmployee"),
            "URL should change from addEmployee after saving. Actual: " + currentUrl);

        System.out.println("Employee 2 added successfully.");
    }
}
