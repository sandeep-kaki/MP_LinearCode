package com.orangehrm.tests;

import com.orangehrm.pages.DashboardPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    /**
     * Test 1: Valid login should land on Dashboard.
     */
    @Test(priority = 1, description = "Verify successful login with valid credentials")
    public void testValidLogin() {
        System.out.println("=== TEST: testValidLogin ===");

        dashboardPage = loginPage.login(ADMIN_USER, ADMIN_PASS);

        boolean isDashboardVisible = dashboardPage.isDashboardDisplayed();
        Assert.assertTrue(isDashboardVisible,
            "Dashboard should be displayed after successful login.");

        System.out.println("Login successful. Dashboard is visible.");
    }

    /**
     * Test 2: Logout should redirect back to the Login page.
     */
    @Test(priority = 2, description = "Verify logout redirects to Login page",
          dependsOnMethods = "testValidLogin")
    public void testLogout() {
        System.out.println("=== TEST: testLogout ===");

        dashboardPage.logout();

        String currentUrl = driver.getCurrentUrl();
        Assert.assertTrue(currentUrl.contains("auth/login"),
            "After logout, URL should contain 'auth/login'. Actual URL: " + currentUrl);

        System.out.println("Logout successful. Current URL: " + currentUrl);
    }
}
