package com.orangehrm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DashboardPage {

    private WebDriver driver;

    // ── Locators ──────────────────────────────────────────────────────────────

    @FindBy(xpath = "//span[text()='Dashboard']")
    private WebElement dashboardHeader;

    @FindBy(xpath = "//span[normalize-space()='PIM']")
    private WebElement pimMenuLink;

    @FindBy(xpath = "//i[@class='oxd-icon bi-caret-down-fill oxd-userdropdown-icon']")
    private WebElement userDropdown;

    @FindBy(linkText = "Logout")
    private WebElement logoutLink;

    // ── Constructor ───────────────────────────────────────────────────────────

    public DashboardPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    public boolean isDashboardDisplayed() {
        try {
            return dashboardHeader.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public AddEmployeePage navigateToAddEmployee() {
        pimMenuLink.click();
        return new AddEmployeePage(driver);
    }

    public void logout() {
        userDropdown.click();
        logoutLink.click();
    }
}
