package com.orangehrm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class AddEmployeePage {

    private WebDriver driver;
    private WebDriverWait wait;

    // ── Locators ──────────────────────────────────────────────────────────────

    @FindBy(xpath = "//a[normalize-space()='Add Employee']")
    private WebElement addEmployeeMenu;

    @FindBy(name = "firstName")
    private WebElement firstNameField;

    @FindBy(name = "middleName")
    private WebElement middleNameField;

    @FindBy(name = "lastName")
    private WebElement lastNameField;

    // "Create Login Details" toggle label/span
    @FindBy(xpath = "//span[@class='oxd-switch-input oxd-switch-input--active --label-right']")
    private WebElement createLoginToggle;

    // Username field inside the login details section
    @FindBy(xpath = "//div[@class='orangehrm-employee-form']//div[contains(@class,'user-password-row')]//preceding-sibling::div//input")
    private WebElement usernameInput;

    // Save button on Add Employee form
    @FindBy(xpath = "//div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']//button[@type='submit'][normalize-space()='Save']")
    private WebElement saveButton;

    // Nationality dropdown trigger
    @FindBy(xpath = "(//div[@class='oxd-select-text oxd-select-text--active'])[1]")
    private WebElement nationalityDropdown;

    // Marital status dropdown trigger
    @FindBy(xpath = "(//div[@class='oxd-select-text oxd-select-text--active'])[2]")
    private WebElement maritalStatusDropdown;

    // Personal Details save button (second form)
    @FindBy(xpath = "(//button[@type='submit'][normalize-space()='Save'])[1]")
    private WebElement personalDetailsSaveButton;

    // ── Constructor ───────────────────────────────────────────────────────────

    public AddEmployeePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        PageFactory.initElements(driver, this);
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    public void clickAddEmployeeMenu() {
        wait.until(ExpectedConditions.elementToBeClickable(addEmployeeMenu));
        addEmployeeMenu.click();
    }

    public void enterFirstName(String firstName) {
        wait.until(ExpectedConditions.visibilityOf(firstNameField));
        firstNameField.clear();
        firstNameField.sendKeys(firstName);
    }

    public void enterMiddleName(String middleName) {
        middleNameField.clear();
        middleNameField.sendKeys(middleName);
    }

    public void enterLastName(String lastName) {
        lastNameField.clear();
        lastNameField.sendKeys(lastName);
    }

    public void enableCreateLoginDetails() {
        try {
            WebElement toggle = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//label[@class='oxd-switch-wrapper']//span")));
            toggle.click();
        } catch (Exception e) {
            System.out.println("Login toggle not found or already enabled: " + e.getMessage());
        }
    }

    public void enterLoginUsername(String username) {
        try {
            WebElement userField = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[contains(@class,'--row')]//div[contains(@class,'--active')]//following::input[@autocomplete='off'][1]")));
            userField.clear();
            userField.sendKeys(username);
        } catch (Exception e) {
            System.out.println("Username field for login not found: " + e.getMessage());
        }
    }

    public void enterLoginPassword(String password) {
        try {
            WebElement passField = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("(//input[@type='password'])[1]")));
            passField.clear();
            passField.sendKeys(password);
        } catch (Exception e) {
            System.out.println("Password field not found: " + e.getMessage());
        }
    }

    public void enterConfirmPassword(String password) {
        try {
            WebElement confirmField = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("(//input[@type='password'])[2]")));
            confirmField.clear();
            confirmField.sendKeys(password);
        } catch (Exception e) {
            System.out.println("Confirm password field not found: " + e.getMessage());
        }
    }

    public void clickSave() {
        wait.until(ExpectedConditions.elementToBeClickable(saveButton));
        saveButton.click();
    }

    public void selectNationality(String nationality) {
        try {
            WebElement natDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//div[@class='oxd-select-text--after'])[1]")));
            natDropdown.click();

            WebElement option = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//span[normalize-space()='" + nationality + "']")));
            option.click();
        } catch (Exception e) {
            System.out.println("Nationality selection failed: " + e.getMessage());
        }
    }

    public void selectMaritalStatus(String status) {
        try {
            WebElement marDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//div[@class='oxd-select-text--after'])[2]")));
            marDropdown.click();

            WebElement option = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//span[normalize-space()='" + status + "']")));
            option.click();
        } catch (Exception e) {
            System.out.println("Marital status selection failed: " + e.getMessage());
        }
    }

    public void savePersonalDetails() {
        try {
            WebElement saveBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//button[@type='submit'][normalize-space()='Save'])[1]")));
            saveBtn.click();
        } catch (Exception e) {
            System.out.println("Personal details save failed: " + e.getMessage());
        }
    }

    /**
     * Convenience method: fills entire Add Employee form in one shot.
     */
    public void fillAndSaveEmployee(String firstName, String middleName, String lastName,
                                     String loginUser, String password,
                                     String nationality, String maritalStatus) {
        clickAddEmployeeMenu();
        enterFirstName(firstName);
        enterMiddleName(middleName);
        enterLastName(lastName);
        enableCreateLoginDetails();
        enterLoginUsername(loginUser);
        enterLoginPassword(password);
        enterConfirmPassword(password);
        clickSave();
        selectNationality(nationality);
        selectMaritalStatus(maritalStatus);
        savePersonalDetails();
    }
}
