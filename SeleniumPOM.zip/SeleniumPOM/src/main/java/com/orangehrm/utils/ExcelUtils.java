package com.orangehrm.utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;

public class ExcelUtils {

    private static Workbook workbook;
    private static Sheet sheet;

    /**
     * Opens the Excel file and selects the given sheet.
     *
     * @param filePath  absolute or relative path to the .xlsx file
     * @param sheetName name of the sheet to read
     */
    public static void setExcelFile(String filePath, String sheetName) throws IOException {
        FileInputStream fis = new FileInputStream(filePath);
        workbook = new XSSFWorkbook(fis);
        sheet = workbook.getSheet(sheetName);
        fis.close();
    }

    /**
     * Returns the String value of a cell by row and column index (0-based).
     */
    public static String getCellData(int rowNum, int colNum) {
        Row row = sheet.getRow(rowNum);
        if (row == null) return "";
        Cell cell = row.getCell(colNum);
        if (cell == null) return "";

        DataFormatter formatter = new DataFormatter();
        return formatter.formatCellValue(cell).trim();
    }

    /**
     * Returns total number of data rows (excludes the header row at index 0).
     */
    public static int getRowCount() {
        return sheet.getLastRowNum(); // lastRowNum is 0-based, so this equals data row count
    }

    public static void closeWorkbook() throws IOException {
        if (workbook != null) {
            workbook.close();
        }
    }
}
