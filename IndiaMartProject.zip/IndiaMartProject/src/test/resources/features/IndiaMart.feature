# IndiaMart automation scenarios
# Tags are used to group and run specific tests

@regression
Feature: IndiaMart Website Automation

  Background:
    Given user opens the IndiaMart website

  @smoke @tc01
  Scenario Outline: Search top 3 car wash services and get phone numbers
    When user searches for "<searchKeyword>" in "<city>"
    Then top 3 service names and phone numbers should be printed

    Examples:
      | searchKeyword     | city    |
      | car wash services | Chennai |

  @smoke @tc02
  Scenario: Extract titles from Food Agriculture and Farming section
    When user clicks on Food Agriculture and Farming category
    Then all subcategory titles should be printed

  @tc03
  Scenario Outline: Validate invalid phone number at login
    When user tries to login with mobile number "<mobileNumber>"
    Then an error message should be shown and screenshot captured

    Examples:
      | mobileNumber |
      | 5476543218   |
      | 1234567890   |

  @tc04
  Scenario: Extract top products from Exporters section
    When user navigates to the Exporters page
    Then top 5 product categories should be printed and screenshot captured
