NOTE: TestData.xlsx should be placed here: src/test/resources/testdata/TestData.xlsx

Expected Sheet: "LoginData"
Columns:
  A (MobileNumber) | B (ExpectedResult)
  5476543218       | invalid
  1234567890       | invalid
  9876543210       | valid

The ExcelUtility.getTestData("LoginData") call will read from this sheet.
You can add more sheets for other test cases as needed.
