package runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

/**
 * Re-runs only the scenarios that failed in the last run.
 * The failed scenario paths are written to target/rerun.txt by TestRunner.
 *
 * How to use:
 *   1. Run TestRunner first (it generates target/rerun.txt)
 *   2. Run this class to re-run only the failed ones
 */
@CucumberOptions(
        features = "@target/rerun.txt",
        glue = {"stepDefinitions", "hooks"},
        plugin = {
                "pretty",
                "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"
        }
)
public class FailedTestsRunner extends AbstractTestNGCucumberTests {

    @Override
    @DataProvider(parallel = false)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
