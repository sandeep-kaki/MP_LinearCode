package runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

/**
 * Main test runner — runs all scenarios in the features folder.
 *
 * plugin options:
 *   - pretty        : readable console output
 *   - allure        : generates Allure report data (run 'mvn allure:serve' to view)
 *   - rerun.txt     : saves failed scenarios so they can be re-run
 */
@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"stepDefinitions", "hooks"},
        plugin = {
                "pretty",
                "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm",
                "rerun:target/rerun.txt"
        },
        tags = "@regression"
)
public class TestRunner extends AbstractTestNGCucumberTests {

    // Returning false here means scenarios run sequentially (not in parallel)
    // Change to true if you want parallel execution
    @Override
    @DataProvider(parallel = false)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
