package utilities;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.URL;

/**
 * BrowserUtility handles WebDriver creation for Chrome, Firefox, and Edge.
 * For Selenium Grid, pass the hub URL and browser name.
 */
public class BrowserUtility {

    private static final Logger log = LogManager.getLogger(BrowserUtility.class);

    // Thread-safe driver so parallel runs don't share the same instance
    private static ThreadLocal<WebDriver> driverThread = new ThreadLocal<>();

    // Default browser if nothing is passed
    private static final String DEFAULT_BROWSER = "chrome";

    public static WebDriver getDriver() {
        return driverThread.get();
    }

    // Creates a local browser instance
    public static void initDriver(String browserName) {
        log.info("Starting browser: {}", browserName);

        WebDriver driver;

        switch (browserName.toLowerCase().trim()) {

            case "firefox":
                FirefoxOptions ffOptions = new FirefoxOptions();
                ffOptions.addArguments("--disable-notifications");
                driver = new FirefoxDriver(ffOptions);
                break;

            case "edge":
                EdgeOptions edgeOptions = new EdgeOptions();
                edgeOptions.addArguments("--disable-notifications");
                driver = new EdgeDriver(edgeOptions);
                break;

            case "chrome":
            default:
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.addArguments("--disable-notifications");
                driver = new ChromeDriver(chromeOptions);
                break;
        }

        driver.manage().window().maximize();
        driverThread.set(driver);
        log.info("Browser started and window maximized");
    }

    // Creates a RemoteWebDriver for Selenium Grid
    // Hub URL example: http://localhost:4444/wd/hub
    public static void initRemoteDriver(String hubUrl, String browserName) {
        log.info("Connecting to Selenium Grid hub: {} | Browser: {}", hubUrl, browserName);

        try {
            org.openqa.selenium.Capabilities caps;

            switch (browserName.toLowerCase().trim()) {
                case "firefox":
                    caps = new FirefoxOptions();
                    break;
                case "edge":
                    caps = new EdgeOptions();
                    break;
                default:
                    caps = new ChromeOptions();
                    break;
            }

            WebDriver driver = new RemoteWebDriver(new URL(hubUrl), caps);
            driver.manage().window().maximize();
            driverThread.set(driver);
            log.info("Connected to Grid successfully");

        } catch (Exception e) {
            log.error("Could not connect to Selenium Grid: {}", e.getMessage());
            throw new RuntimeException("Grid connection failed", e);
        }
    }

    public static void quitDriver() {
        WebDriver driver = driverThread.get();
        if (driver != null) {
            driver.quit();
            driverThread.remove();
            log.info("Browser closed");
        }
    }
}
