package utilities;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Reads test data from an Excel (.xlsx) file.
 * Uses Apache POI under the hood.
 *
 * Excel file path: src/test/resources/testdata/TestData.xlsx
 */
public class ExcelUtility {

    private static final Logger log = LogManager.getLogger(ExcelUtility.class);
    private static final String FILE_PATH = "src/test/resources/testdata/TestData.xlsx";

    /**
     * Reads all rows from a given sheet and returns them as a list of string arrays.
     * Row 0 is treated as the header and is skipped.
     */
    public static List<String[]> getTestData(String sheetName) {
        List<String[]> data = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(FILE_PATH);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);

            if (sheet == null) {
                log.warn("Sheet '{}' not found in {}", sheetName, FILE_PATH);
                return data;
            }

            int totalRows = sheet.getLastRowNum();
            int totalCols = sheet.getRow(0).getLastCellNum();

            // Start from row 1 to skip the header
            for (int rowIndex = 1; rowIndex <= totalRows; rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                String[] rowData = new String[totalCols];

                for (int colIndex = 0; colIndex < totalCols; colIndex++) {
                    Cell cell = row.getCell(colIndex);
                    rowData[colIndex] = (cell == null) ? "" : cell.toString().trim();
                }
                data.add(rowData);
            }

            log.info("Read {} rows from sheet '{}'", data.size(), sheetName);

        } catch (IOException e) {
            log.error("Could not read Excel file: {}", e.getMessage());
        }

        return data;
    }
}
