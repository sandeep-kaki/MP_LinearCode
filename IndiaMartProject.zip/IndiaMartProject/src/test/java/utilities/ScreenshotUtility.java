package utilities;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Handles taking and saving screenshots.
 * Screenshots are saved in the Screenshots/ folder with a timestamp.
 */
public class ScreenshotUtility {

    private static final Logger log = LogManager.getLogger(ScreenshotUtility.class);
    private static final String SCREENSHOT_DIR = "./Screenshots/";

    // Makes sure the Screenshots folder exists on first use
    static {
        File dir = new File(SCREENSHOT_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    /**
     * Takes a screenshot and saves it with the given file name.
     * Returns the full path of the saved file.
     */
    public static String capture(WebDriver driver, String fileName) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fullPath = SCREENSHOT_DIR + fileName + "_" + timestamp + ".png";

        try {
            File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileHandler.copy(src, new File(fullPath));
            log.info("Screenshot saved: {}", fullPath);
        } catch (IOException e) {
            log.error("Failed to save screenshot '{}': {}", fileName, e.getMessage());
        }

        return fullPath;
    }
}
