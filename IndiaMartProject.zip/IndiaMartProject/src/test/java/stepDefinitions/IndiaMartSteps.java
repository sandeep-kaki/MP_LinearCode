package stepDefinitions;

import io.cucumber.java.en.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import pages.*;
import utilities.BrowserUtility;
import utilities.ScreenshotUtility;
import utilities.WaitUtility;
import java.util.List;

/**
 * Step definitions for all IndiaMart scenarios.
 * Each method here maps to a Gherkin step in IndiaMart.feature.
 */
public class IndiaMartSteps {

    private static final Logger log = LogManager.getLogger(IndiaMartSteps.class);
    private static final String BASE_URL = "https://www.indiamart.com/";

    private WebDriver driver;
    private HomePage homePage;

    // ======================== Background ========================

    @Given("user opens the IndiaMart website")
    public void userOpensTheWebsite() {
        driver = BrowserUtility.getDriver();
        homePage = new HomePage(driver);
        homePage.openWebsite(BASE_URL);
        log.info("Website opened");
    }

    // ======================== TC01 - Car Wash Services ========================

    @When("user searches for {string} in {string}")
    public void userSearchesFor(String keyword, String city) {
        String currentCity = homePage.getSelectedCity();

        if (!currentCity.equalsIgnoreCase(city)) {
            homePage.changeCity(city);
        }

        homePage.searchFor(keyword);
        log.info("Searched for '{}' in '{}'", keyword, city);
    }

    @Then("top 3 service names and phone numbers should be printed")
    public void top3ServicesShouldBePrinted() {
        SearchResultsPage resultsPage = new SearchResultsPage(driver);
        List<String[]> services = resultsPage.getTopServices(3);

        System.out.println("\n====== INDIA MART – TOP 3 CAR WASH SERVICES ======");
        System.out.println("---------------------------------------------");

        for (int i = 0; i < services.size(); i++) {
            System.out.println((i + 1) + ". " + services.get(i)[0]);
            System.out.println("   Phone : " + services.get(i)[1]);
        }
    }

    // ======================== TC02 - Food, Agriculture ========================

    @When("user clicks on Food Agriculture and Farming category")
    public void userClicksFoodAgriCategory() {
        driver.navigate().back();

        homePage = new HomePage(driver);
        homePage.closePopupIfPresent();

        JavascriptExecutor js = (JavascriptExecutor) driver;

        WebElement agriLink = WaitUtility.waitForVisible(driver,
                By.xpath("//a[normalize-space()=\"Food, Agriculture & Farming\"]"));
        js.executeScript("arguments[0].scrollIntoView()", agriLink);
        homePage.closePopupIfPresent();
        agriLink.click();
        log.info("Clicked Food, Agriculture & Farming");
    }

    @Then("all subcategory titles should be printed")
    public void allSubcategoryTitlesShouldBePrinted() {
        List<WebElement> subTitles = driver.findElements(
                By.xpath("//h2[normalize-space()='Food, Agriculture & Farming']/following-sibling::div//div[contains(@class,'product-item')]//h3"));

        System.out.println("\n====== Food, Agriculture & Farming ======");
        System.out.println("---------------------------------------------");

        for (WebElement title : subTitles) {
            System.out.println(title.getText());
        }

        log.info("Printed {} subcategory titles", subTitles.size());

        // Scroll back to top
        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,-document.body.scrollHeight)");
    }

    // ======================== TC03 - Invalid Phone Login ========================

    @When("user tries to login with mobile number {string}")
    public void userTriesToLoginWithMobile(String mobileNumber) {
        homePage.clickSignIn();

        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterMobileNumber(mobileNumber);
        log.info("Entered mobile number: {}", mobileNumber);
    }

    @Then("an error message should be shown and screenshot captured")
    public void errorMessageShouldBeShownAndScreenshotCaptured() {
        LoginPage loginPage = new LoginPage(driver);

        String errMsg = loginPage.getErrorMessage();

        System.out.println("\n====== INVALID PHONE NUMBER ======");
        System.out.println("---------------------------------------------");
        System.out.println("Error: " + errMsg);

        String path = ScreenshotUtility.capture(driver, "invalid_number_error");
        System.out.println("Screenshot saved: " + path);

        loginPage.closeLoginModal();
    }

    // ======================== TC04 - Exporters ========================

    @When("user navigates to the Exporters page")
    public void userNavigatesToExporters() {
        homePage = new HomePage(driver);
        homePage.clickExporters();
    }

    @Then("top 5 product categories should be printed and screenshot captured")
    public void top5ProductCategoriesShouldBePrinted() {
        ExportersPage exportersPage = new ExportersPage(driver);

        String heading = exportersPage.getSectionHeading();
        List<WebElement> categories = exportersPage.getTopProductCategories(5);

        System.out.println("\n====== " + heading + " ======");
        System.out.println("---------------------------------------------");

        for (WebElement cat : categories) {
            System.out.println(cat.getText());
        }

        exportersPage.scrollToProductSection();

        String path = ScreenshotUtility.capture(driver, "top_product_categories_india");
        System.out.println("Screenshot saved: " + path);

        log.info("Exported top 5 product categories and screenshot taken");
    }
}
