package hooks;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import utilities.BrowserUtility;
import utilities.ScreenshotUtility;

/**
 * Cucumber Hooks — runs before and after each scenario.
 * Handles browser setup, teardown, and failure screenshots.
 */
public class Hooks {

    private static final Logger log = LogManager.getLogger(Hooks.class);

    // Change this to "firefox" or "edge" to run on a different browser
    private static final String BROWSER = "chrome";

    @Before
    public void setUp(Scenario scenario) {
        log.info("====== Starting scenario: {} ======", scenario.getName());
        BrowserUtility.initDriver(BROWSER);
    }

    @After
    public void tearDown(Scenario scenario) {
        if (scenario.isFailed()) {
            log.warn("Scenario FAILED: {} — taking failure screenshot", scenario.getName());
            ScreenshotUtility.capture(BrowserUtility.getDriver(), "FAILED_" + scenario.getName().replaceAll(" ", "_"));
        }
        BrowserUtility.quitDriver();
        log.info("====== Finished scenario: {} | Status: {} ======", scenario.getName(), scenario.getStatus());
    }
}
