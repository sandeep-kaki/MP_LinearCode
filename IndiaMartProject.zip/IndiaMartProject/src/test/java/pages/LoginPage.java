package pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.WaitUtility;

/**
 * Represents the Login modal/page on IndiaMart.
 */
public class LoginPage {

    private static final Logger log = LogManager.getLogger(LoginPage.class);
    private WebDriver driver;

    // ID is priority 1 — always use it when available
    @FindBy(id = "mobile")
    private WebElement mobileInput;

    @FindBy(id = "mobile_err")
    private WebElement mobileErrorMessage;

    @FindBy(id = "close_s")
    private WebElement closeLoginBtn;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void enterMobileNumber(String mobileNumber) {
        WaitUtility.waitForElement(driver, mobileInput);
        mobileInput.sendKeys(mobileNumber);
        log.info("Entered mobile number: {}", mobileNumber);
        mobileInput.submit();
    }

    public String getErrorMessage() {
        try {
            WaitUtility.waitForElement(driver, mobileErrorMessage);
            return mobileErrorMessage.getText().trim();
        } catch (Exception e) {
            return "";
        }
    }

    public void closeLoginModal() {
        try {
            closeLoginBtn.click();
            log.info("Closed login modal");
        } catch (Exception e) {
            log.warn("Login close button not found");
        }
    }
}
