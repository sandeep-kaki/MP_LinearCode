package pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.WaitUtility;

/**
 * Represents the IndiaMart Home Page.
 * PageFactory initializes all @FindBy elements automatically.
 *
 * Locator priority used here: ID > Name > XPath (as per best practices)
 */
public class HomePage {

    private static final Logger log = LogManager.getLogger(HomePage.class);
    private WebDriver driver;

    // --- Page Elements ---

    // ID is the best locator — using it wherever available
    @FindBy(id = "hd_usercity")
    private WebElement cityLabel;

    @FindBy(id = "hd_city_sugg")
    private WebElement cityInput;

    // XPath used here because there's no ID/name on this anchor
    @FindBy(xpath = "//*[@id='anchor']")
    private WebElement firstCitySuggestion;

    // Name locator for the search box
    @FindBy(name = "ss")
    private WebElement searchBox;

    @FindBy(id = "user_sign_in")
    private WebElement signInButton;

    @FindBy(linkText = "Food, Agriculture & Farming")
    private WebElement foodAgriLink;

    // ID for close button of popup
    @FindBy(id = "idfpclose")
    private WebElement popupCloseBtn;

    @FindBy(id = "exporters")
    private WebElement exportersLink;

    // --- Constructor: initializes PageFactory ---
    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // --- Page Actions ---

    public void openWebsite(String url) {
        driver.get(url);
        log.info("Opened URL: {}", url);
    }

    public String getSelectedCity() {
        return cityLabel.getText().trim();
    }

    public void changeCity(String cityName) {
        log.info("Changing city to: {}", cityName);
        cityLabel.click();
        cityInput.sendKeys(cityName);
        WaitUtility.waitForClickable(driver, org.openqa.selenium.By.xpath("//*[@id='anchor']")).click();
    }

    public void searchFor(String keyword) {
        log.info("Searching for: {}", keyword);
        searchBox.sendKeys(keyword, Keys.ENTER);
    }

    public void clickSignIn() {
        signInButton.click();
        log.info("Clicked Sign In button");
    }

    public void clickFoodAgriLink() {
        log.info("Clicking Food, Agriculture & Farming link");
        foodAgriLink.click();
    }

    public void closePopupIfPresent() {
        try {
            if (popupCloseBtn.isDisplayed()) {
                popupCloseBtn.click();
                log.info("Closed popup");
            }
        } catch (Exception e) {
            // Popup not present — that's fine
        }
    }

    public void clickExporters() {
        exportersLink.click();
        log.info("Clicked Exporters link");
    }
}
