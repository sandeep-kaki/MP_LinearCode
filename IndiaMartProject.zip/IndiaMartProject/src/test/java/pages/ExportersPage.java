package pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.WaitUtility;
import java.util.List;

/**
 * Handles the Exporters page — top product categories section.
 */
public class ExportersPage {

    private static final Logger log = LogManager.getLogger(ExportersPage.class);
    private WebDriver driver;

    // Heading that shows "Top Product Categories" or similar
    @FindBy(xpath = "//h2[@class=\"text-center font-normal text-gray-800 mb-6 text-[20px] md:text-[28px] leading-[28px]\"]")
    private WebElement sectionHeading;

    // All product category links — CSS selector used since there's no ID here
    @FindBy(xpath = "//a[contains(@class,'text-base') and contains(@class,'font-semibold')]")
    private List<WebElement> productCategories;

    // The section we scroll to for a screenshot
    @FindBy(css = "div.px-4.py-8.bg-gray-50")
    private WebElement productSection;

    public ExportersPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public String getSectionHeading() {
        try {
            WaitUtility.waitForElement(driver, sectionHeading);
            return sectionHeading.getText().trim();
        } catch (Exception e) {
            return "Top Products";
        }
    }

    public List<WebElement> getTopProductCategories(int count) {
        int take = Math.min(count, productCategories.size());
        log.info("Fetching top {} product categories", take);
        return productCategories.subList(0, take);
    }

    public void scrollToProductSection() {
        try {
            WaitUtility.waitForElement(driver, productSection);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView()", productSection);
        } catch (Exception e) {
            log.warn("Could not scroll to product section");
        }
    }
}
