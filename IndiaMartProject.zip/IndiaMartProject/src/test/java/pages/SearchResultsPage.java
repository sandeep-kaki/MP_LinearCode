package pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.WaitUtility;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles the search results page where car wash service cards appear.
 */
public class SearchResultsPage {

    private static final Logger log = LogManager.getLogger(SearchResultsPage.class);
    private WebDriver driver;

    // All service card links on results page
    @FindBy(xpath = "//a[@class='cardlinks']")
    private List<WebElement> serviceCards;

    // Close button for unlock popup inside a service detail page
    @FindBy(id = "idfpclose")
    private List<WebElement> popupCloseButtons;

    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Wait for search results to load, then collect top N service card details
    public List<String[]> getTopServices(int count) {
        WaitUtility.waitForVisible(driver, By.xpath("//a[@class='cardlinks']"));
        PageFactory.initElements(driver, this); // re-init after navigation

        List<String[]> services = new ArrayList<>();
        List<String> urls = new ArrayList<>();
        List<String> names = new ArrayList<>();

        for (int i = 0; i < Math.min(count, serviceCards.size()); i++) {
            names.add(serviceCards.get(i).getText());
            urls.add(serviceCards.get(i).getAttribute("href"));
        }

        String mainWindow = driver.getWindowHandle();

        for (int i = 0; i < urls.size(); i++) {
            ((JavascriptExecutor) driver).executeScript("window.open(arguments[0], '_blank');", urls.get(i));

            // Switch to newly opened tab
            for (String win : driver.getWindowHandles()) {
                if (!win.equals(mainWindow)) {
                    driver.switchTo().window(win);
                    break;
                }
            }

            closePopupIfPresent();

            String phone = extractPhoneNumber();
            services.add(new String[]{names.get(i), phone});

            driver.close();
            driver.switchTo().window(mainWindow);
        }

        log.info("Fetched {} service entries", services.size());
        return services;
    }

    private void closePopupIfPresent() {
        try {
            List<WebElement> skipBtns = driver.findElements(By.id("idfpclose"));
            if (!skipBtns.isEmpty()) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", skipBtns.get(0));
                Thread.sleep(500);
            }
        } catch (Exception e) {
            // No popup — continue
        }
    }

    private String extractPhoneNumber() {
        try {
            // XPath used because the phone element has a specific ID + nested anchor structure
            WebElement phoneEl = WaitUtility.waitForVisible(driver,
                    By.xpath("//*[@id='pns_no2']//a[contains(@href,'tel')]"));
            return phoneEl.getAttribute("href").replace("tel:", "");
        } catch (Exception e) {
            return "Hidden (unlock required)";
        }
    }
}
