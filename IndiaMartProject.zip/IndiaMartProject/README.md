# IndiaMart Selenium Automation Project

## Tech Stack
- Selenium Java 4
- Cucumber 7 (BDD)
- TestNG
- Page Object Model + PageFactory
- Allure Reports
- Log4j2
- Apache POI (Excel data-driven)

---

## Project Structure

```
src/test/java/
  pages/              → Page Object classes (HomePage, LoginPage, etc.)
  stepDefinitions/    → Cucumber step definitions
  hooks/              → Before/After hooks (browser setup, screenshots)
  runners/            → TestRunner, SmokeRunner, FailedTestsRunner
  utilities/          → BrowserUtility, WaitUtility, ScreenshotUtility, ExcelUtility

src/test/resources/
  features/           → Cucumber .feature files
  testdata/           → TestData.xlsx
  testng.xml          → TestNG suite config
  log4j2.xml          → Log4j logging config
```

---

## How to Run

### Full regression run
```
mvn clean test
```

### Smoke tests only
Right-click `SmokeRunner.java` → Run as TestNG

### Re-run failed tests
Run `TestRunner` first, then run `FailedTestsRunner`

### View Allure Report
```
mvn allure:serve
```

---

## Changing the Browser
In `hooks/Hooks.java`, change:
```java
private static final String BROWSER = "chrome"; // chrome | firefox | edge
```

---

## Selenium Grid
In `BrowserUtility.java`, call:
```java
BrowserUtility.initRemoteDriver("http://localhost:4444/wd/hub", "chrome");
```
Then update `Hooks.java` to call `initRemoteDriver` instead of `initDriver`.

---

## Tags
| Tag         | What it runs        |
|-------------|---------------------|
| @regression | All scenarios       |
| @smoke      | TC01 + TC02 only    |
| @tc01       | Car wash search     |
| @tc02       | Food/Agri titles    |
| @tc03       | Invalid phone login |
| @tc04       | Exporters section   |
