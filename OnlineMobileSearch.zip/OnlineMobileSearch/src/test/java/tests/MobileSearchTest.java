package tests;

import pages.HomePage;
import pages.SearchResultsPage;
import utils.BaseTest;
import utils.ExcelUtils;
import utils.ScreenshotUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

public class MobileSearchTest extends BaseTest {

    @Test
    public void searchMobilesFromExcel() throws IOException {
        int rowCount = ExcelUtils.getRowCount();
        for (int i = 1; i <= rowCount; i++) {
            String keyword = ExcelUtils.getCellData(i, 0);

            HomePage homePage = new HomePage(driver);
            homePage.searchFor(keyword);

            SearchResultsPage resultsPage = new SearchResultsPage(driver);
            Assert.assertTrue(resultsPage.isResultsDisplayed(), "No results found for: " + keyword);

            ScreenshotUtils.takeScreenshot(driver, "search_" + keyword.replace(" ", "_"));

            driver.navigate().back();
        }
    }

    @Test
    public void verifySearchResultTitle() throws IOException {
        String keyword = ExcelUtils.getCellData(1, 0);

        HomePage homePage = new HomePage(driver);
        homePage.searchFor(keyword);

        SearchResultsPage resultsPage = new SearchResultsPage(driver);
        Assert.assertTrue(resultsPage.isResultsDisplayed(), "Results not displayed");
        Assert.assertFalse(resultsPage.getFirstProductTitle().isEmpty(), "Product title is empty");

        ScreenshotUtils.takeScreenshot(driver, "verifyTitle");
    }

    @Test
    public void verifyResultCount() throws IOException {
        String keyword = ExcelUtils.getCellData(1, 0);

        HomePage homePage = new HomePage(driver);
        homePage.searchFor(keyword);

        SearchResultsPage resultsPage = new SearchResultsPage(driver);
        int count = resultsPage.getResultCount();
        Assert.assertTrue(count > 0, "Result count is zero for: " + keyword);

        ScreenshotUtils.takeScreenshot(driver, "resultCount");
    }
}
