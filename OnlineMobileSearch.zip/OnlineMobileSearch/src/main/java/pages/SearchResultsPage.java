package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class SearchResultsPage {

    WebDriver driver;

    @FindBy(css = "span.a-size-medium.a-color-base.a-text-normal")
    List<WebElement> productTitles;

    @FindBy(css = "span.a-price-whole")
    List<WebElement> productPrices;

    @FindBy(css = "span.a-size-base.s-underline-text")
    List<WebElement> productRatings;

    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public String getFirstProductTitle() {
        if (!productTitles.isEmpty()) {
            return productTitles.get(0).getText();
        }
        return "";
    }

    public boolean isResultsDisplayed() {
        return !productTitles.isEmpty();
    }

    public int getResultCount() {
        return productTitles.size();
    }
}
