
package pages;

import factory.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.WaitUtils;

public class LoginPage {

    WebDriver driver;

    public LoginPage() {
        this.driver = DriverFactory.getDriver();
        PageFactory.initElements(driver, this);
    }

    @FindBy(name = "username")
    private WebElement txt_username;

    @FindBy(name = "password")
    private WebElement txt_password;

    @FindBy(css = "button[type='submit']")
    private WebElement btn_login;

    public void enterUsername(String username) {
        WaitUtils.waitForElement(txt_username, 20);
        txt_username.sendKeys(username);
    }

    public void enterPassword(String password) {
        txt_password.sendKeys(password);
    }

    public DashboardPage clickLogin() {
        btn_login.click();

	    // Wait until Dashboard screen loads
	    DashboardPage dashboard = new DashboardPage();
	    WaitUtils.waitForElement(dashboard.getDashboardHeader(), 20);

    return dashboard;

    }
    public boolean isLoginButtonEnabled() {
        return btn_login.isEnabled();
    }
}