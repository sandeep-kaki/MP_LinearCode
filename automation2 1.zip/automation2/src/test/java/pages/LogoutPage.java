
package pages;

import factory.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.WaitUtils;

public class LogoutPage {

    WebDriver driver;

    public LogoutPage() {
        this.driver = DriverFactory.getDriver();
        PageFactory.initElements(driver, this);
    }

    // Dropdown tab in top bar
    @FindBy(xpath = "//span[@class='oxd-userdropdown-tab']")
    private WebElement userDropdown;

    // Logout option inside dropdown menu
    @FindBy(xpath = "//a[normalize-space()='Logout']")
    private WebElement logoutBtn;

    public void clickUserDropdown() {
        WaitUtils.waitForElement(userDropdown, 10);
        userDropdown.click();
    }

    public void clickLogout() {
        WaitUtils.waitForElement(logoutBtn, 10);
        logoutBtn.click();
    }
}