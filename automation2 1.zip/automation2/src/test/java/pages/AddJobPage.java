
package pages;

import factory.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utils.ConfigReader;
import utils.WaitUtils;

public class AddJobPage {

    WebDriver driver;

    public AddJobPage() {
        this.driver = DriverFactory.getDriver();
        PageFactory.initElements(driver, this);
    }

    // Correct Job Title input field locator
    @FindBy(xpath = "//label[text()='Job Title']/following::input[1]")
    private WebElement jobTitleInput;

    @FindBy(css = "button[type='submit']")
    private WebElement saveButton;

    // Wait indicator after adding job (Job Titles table header)
    @FindBy(xpath = "//div[@class='oxd-table-header']//div[text()='Job Titles']")
    private WebElement jobTitlesHeader;

    public void addJob(String title) {

        // Wait for input, type job title
        WaitUtils.waitForElement(jobTitleInput,Integer.parseInt(ConfigReader.initProperties().getProperty("timeout")));
        jobTitleInput.clear();
        jobTitleInput.sendKeys(title);

        // Click Save
        WaitUtils.waitForElement(saveButton, Integer.parseInt(ConfigReader.initProperties().getProperty("timeout")));
        saveButton.click();

        // Wait until page returns to Job Titles list
        WaitUtils.waitForElement(jobTitlesHeader, Integer.parseInt(ConfigReader.initProperties().getProperty("timeout")));
    }
}