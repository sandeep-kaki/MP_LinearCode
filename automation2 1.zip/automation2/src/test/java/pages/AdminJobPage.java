package pages;

import factory.DriverFactory;

import java.util.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.WaitUtils;

public class AdminJobPage {

    WebDriver driver;

    public AdminJobPage() {
        this.driver = DriverFactory.getDriver();
        PageFactory.initElements(driver, this);
    }

    // 1. Admin sidebar
    @FindBy(xpath = "//span[normalize-space()='Admin']")
    private WebElement adminSidebar;
    

	@FindBy(xpath = "//span[normalize-space()='Job']")
	private WebElement jobTab;
	
	@FindBy(xpath = "//a[normalize-space()='Job Titles']")
	private WebElement jobTitlesLink;


    // 4. Add button
    @FindBy(css = "button.oxd-button--secondary")
    private WebElement addButton;

    public void goToAdminModule() {
        WaitUtils.waitForElement(adminSidebar, 10);
        adminSidebar.click();
    }

    public void openJobTitles() {
        WaitUtils.waitForElement(jobTab, 10);
        jobTab.click();

        WaitUtils.waitForElement(jobTitlesLink, 10);
        jobTitlesLink.click();
    }

    public AddJobPage clickAddButton() {
        WaitUtils.waitForElement(addButton, 10);
        addButton.click();
        return new AddJobPage();
    }
    public boolean isJobTitlesPresent() {
        WaitUtils.waitForElement(jobTab, 10);
        jobTab.click();

        WaitUtils.waitForElement(jobTitlesLink, 10);
        return jobTitlesLink.isDisplayed();
    }

    @FindBy(xpath = "//div[@class='oxd-table-body']//div[@role='row']/div[2]")
    private java.util.List<WebElement> jobTitleList;

	@FindBy(xpath = "//div[@class='oxd-table-body']")
	private WebElement oxdTableBody;

	public List<String> getAllJobTitles() {
	    
	    WaitUtils.waitForElement(oxdTableBody, 10);

	    List<String> titles = new ArrayList<>();

	    for (WebElement e : jobTitleList) {
	        titles.add(e.getText().trim());
	    }

	    return titles;
	}
    
}
