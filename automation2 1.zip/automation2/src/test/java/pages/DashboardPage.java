package pages;

import factory.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.WaitUtils;

public class DashboardPage {

    WebDriver driver;

    public DashboardPage() {
        this.driver = DriverFactory.getDriver();
        PageFactory.initElements(driver, this);
    }

    // Sidebar Dashboard label
    @FindBy(xpath = "//span[text()='Dashboard']")
    private WebElement dashboardText;
	
	public WebElement getDashboardHeader() {
	    return dashboardText;
	}

    // Sidebar Admin link
    @FindBy(xpath = "//span[text()='Admin']")
    private WebElement adminTab;

    // Wait for dashboard to load
    public void waitForDashboard() {
        WaitUtils.waitForElement(dashboardText, 10);
    }

    // Click Admin sidebar
    public void clickAdminTab() {
        WaitUtils.waitForElement(adminTab, 10);   // <<< IMPORTANT
        adminTab.click();
    }

    public String getCurrentURL() {
        return driver.getCurrentUrl();
    }
}