
package tests;

import base.BaseTest;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class AddJobTest extends BaseTest {

    LoginPage login;
    DashboardPage dashboard;
    AdminJobPage adminJob;
    AddJobPage addJob;

    @Test(priority = 1)
    public void verifyDashboardURL() {
        login = new LoginPage();
        login.enterUsername(prop.getProperty("username"));
        login.enterPassword(prop.getProperty("password"));

        dashboard = login.clickLogin();
        dashboard.waitForDashboard();

        Assert.assertTrue(dashboard.getCurrentURL().contains("dashboard"));
    }

    @Test(priority = 2, dependsOnMethods = "verifyDashboardURL")
    public void verifyJobTitlesIsPresent() {
        adminJob = new AdminJobPage();
        adminJob.goToAdminModule();
        Assert.assertTrue(adminJob.isJobTitlesPresent());
    }

    @Test(priority = 3, dependsOnMethods = "verifyJobTitlesIsPresent")
    public void addNewJobTest() {
        adminJob.openJobTitles();
        addJob = adminJob.clickAddButton();
        addJob.addJob("Automation Tester");
    }

    @Test(priority = 4, dependsOnMethods = "addNewJobTest")
    public void verifyJobAddedInList() {

        adminJob.goToAdminModule();     // absolutely required
        adminJob.openJobTitles();       // now the element exists

        List<String> titles = adminJob.getAllJobTitles();
        Assert.assertTrue(titles.contains("Automation Tester"),
                "'Automation Tester' not found!");
    }

    @Test(priority = 5, dependsOnMethods = "verifyJobAddedInList")
    public void logoutTest() {
        LogoutPage logout = new LogoutPage();
        logout.clickUserDropdown();
        logout.clickLogout();

        Assert.assertTrue(driver.getCurrentUrl().contains("auth/login"));
    }

}