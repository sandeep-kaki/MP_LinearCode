package tests;

import org.testng.annotations.Test;
import pages.FilterPage;
import pages.HomePage;
import pages.ResultsPage;
import pages.SearchPage;
import utils.ExcelReader;
import utils.ScreenshotUtil;

import java.io.IOException;

public class FlipkartTest extends BaseTest {

    @Test
    public void flipkartMobileSearchTest() throws InterruptedException, IOException {

        // read test data from excel
        String excelPath = System.getProperty("user.dir") + "/src/test/resources/TestData.xlsx";
        ExcelReader excel = new ExcelReader(excelPath, "TestData");

        String searchKeyword   = excel.getCellData(1, 0); // "mobile"
        String suggestionText  = excel.getCellData(1, 1); // "mobile under 15000"
        String osFilter        = excel.getCellData(1, 2); // "Pie"
        int    priceLimit      = Integer.parseInt(excel.getCellData(1, 3)); // 30000

        excel.close();

        // --- Home Page ---
        HomePage homePage = new HomePage(driver);
        homePage.closePopup();
        homePage.enterSearchText(searchKeyword);

        Thread.sleep(1000);

        // --- Search Suggestions ---
        SearchPage searchPage = new SearchPage(driver);
        searchPage.selectSuggestion(suggestionText);

        Thread.sleep(3000);

        // --- Filters ---
        FilterPage filterPage = new FilterPage(driver);

        // drag price slider left by -175px to reduce max price
        filterPage.dragPriceSlider(-175);

        Thread.sleep(5000);

        // expand OS filter and select Pie
        filterPage.clickOsFilterSection();
        filterPage.clickOsMoreLink();
        filterPage.selectPieOs();

        // screenshot after applying filters
        ScreenshotUtil.takeScreenshot(driver, "sc1");

        // sort by newest first
        filterPage.sortByNewest();

        Thread.sleep(2000);

        // screenshot after sorting
        ScreenshotUtil.takeScreenshot(driver, "sc2");

        // --- Results ---
        ResultsPage resultsPage = new ResultsPage(driver);

        System.out.println("\n====== Top 5 Mobiles ======");

        for (int i = 0; i < 5; i++) {
            String name  = resultsPage.getProductName(i);
            String price = resultsPage.getProductPrice(i);

            System.out.println((i + 1) + ". " + name);
            System.out.println("   Price: " + price);

            // validate first product price
            if (i == 0) {
                int priceInt = Integer.parseInt(price.replaceAll("[^0-9]", ""));

                if (priceInt < priceLimit) {
                    System.out.println("\n   Validation Passed: First mobile price is less than " + priceLimit);
                } else {
                    System.out.println("\n   Validation Failed: First mobile price is " + price);
                }
            }
        }

        System.out.println("===========================\n");
    }
}
