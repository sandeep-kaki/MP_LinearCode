package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class SearchPage {

    WebDriver driver;
    WebDriverWait wait;

    // all autocomplete suggestions in dropdown
    @FindBy(xpath = "//div[@class='lfFUxn']//li")
    private List<WebElement> searchSuggestions;

    public SearchPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    // click on suggestion that matches keyword
    public void selectSuggestion(String keyword) {
        wait.until(ExpectedConditions.visibilityOfAllElements(searchSuggestions));

        for (WebElement suggestion : searchSuggestions) {
            if (suggestion.getText().toLowerCase().contains(keyword.toLowerCase())) {
                suggestion.click();
                break;
            }
        }
    }
}
