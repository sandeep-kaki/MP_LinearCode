package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class FilterPage {

    WebDriver driver;
    WebDriverWait wait;
    Actions actions;
    JavascriptExecutor js;

    // price slider max handle
    @FindBy(xpath = "//div[@id='container']//div[@class='lPYKVv jVLYlZ']")
    private WebElement priceSliderMax;

    // OS filter section header
    @FindBy(xpath = "//div[text()='Operating System Version Name']/parent::div")
    private WebElement osFilterSection;

    // "more" link inside OS filter
    @FindBy(xpath = "//div[text()='Operating System Version Name']/parent::*/following-sibling::*//span")
    private WebElement osMoreLink;

    // Pie OS checkbox
    @FindBy(xpath = "//*[text()='Pie']/preceding-sibling::div")
    private WebElement pieOsCheckbox;

    // Newest First sort option
    @FindBy(xpath = "//*[text()='Newest First']")
    private WebElement newestFirstSort;

    public FilterPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.actions = new Actions(driver);
        this.js = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }

    // drag max price slider to reduce price range
    public void dragPriceSlider(int xOffset) {
        wait.until(ExpectedConditions.visibilityOf(priceSliderMax));
        actions.dragAndDropBy(priceSliderMax, xOffset, 0).perform();
    }

    // expand OS filter section
    public void clickOsFilterSection() {
        wait.until(ExpectedConditions.elementToBeClickable(osFilterSection)).click();
    }

    // click show more inside OS filter
    public void clickOsMoreLink() {
        wait.until(ExpectedConditions.elementToBeClickable(osMoreLink)).click();
    }

    // select Pie OS using JS click
    public void selectPieOs() {
        WebElement pie = wait.until(ExpectedConditions.elementToBeClickable(pieOsCheckbox));
        js.executeScript("arguments[0].click();", pie);
    }

    // sort by newest first using JS click
    public void sortByNewest() {
        WebElement newest = wait.until(ExpectedConditions.elementToBeClickable(newestFirstSort));
        js.executeScript("arguments[0].click();", newest);
    }
}
