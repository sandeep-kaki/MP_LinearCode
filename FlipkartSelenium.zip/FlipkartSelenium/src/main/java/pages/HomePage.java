package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

    WebDriver driver;

    // close login popup button
    @FindBy(xpath = "//*[@class='q7ywiQ']/span[@role='button']")
    private WebElement closeLoginPopup;

    // search box
    @FindBy(name = "q")
    private WebElement searchBox;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void closePopup() {
        closeLoginPopup.click();
    }

    public void enterSearchText(String text) {
        searchBox.sendKeys(text);
    }
}
