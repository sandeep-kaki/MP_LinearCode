package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class ResultsPage {

    WebDriver driver;
    WebDriverWait wait;

    // product name elements
    @FindBy(xpath = "//*[@class='col col-7-12']/div[@class='RG5Slk']")
    private List<WebElement> productNames;

    // product price elements
    @FindBy(xpath = "//*[@class='oFEPlD']//*[@class='hZ3P6w DeU9vF']")
    private List<WebElement> productPrices;

    public ResultsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    // get product name by index (0-based)
    public String getProductName(int index) {
        wait.until(ExpectedConditions.visibilityOfAllElements(productNames));
        return productNames.get(index).getText();
    }

    // get product price by index (0-based)
    public String getProductPrice(int index) {
        wait.until(ExpectedConditions.visibilityOfAllElements(productPrices));
        return productPrices.get(index).getText();
    }

    // how many products loaded
    public int getProductCount() {
        wait.until(ExpectedConditions.visibilityOfAllElements(productNames));
        return productNames.size();
    }
}
