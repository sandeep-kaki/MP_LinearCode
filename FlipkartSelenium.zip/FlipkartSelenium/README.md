# Flipkart Selenium - Page Object Model Project

## Project Structure

```
FlipkartSelenium/
│
├── src/
│   ├── main/java/
│   │   ├── pages/
│   │   │   ├── HomePage.java         -> Flipkart home page (popup + search)
│   │   │   ├── SearchPage.java       -> Search suggestions dropdown
│   │   │   ├── FilterPage.java       -> Price slider, OS filter, sort
│   │   │   └── ResultsPage.java      -> Product name & price results
│   │   │
│   │   └── utils/
│   │       ├── DriverManager.java    -> ChromeDriver setup & teardown
│   │       ├── ExcelReader.java      -> Apache POI - reads Excel test data
│   │       └── ScreenshotUtil.java   -> Takes and saves screenshots
│   │
│   └── test/
│       ├── java/tests/
│       │   ├── BaseTest.java         -> @BeforeClass / @AfterClass
│       │   └── FlipkartTest.java     -> Main test case
│       │
│       └── resources/
│           └── TestData.xlsx         -> Test data (search keyword, filter, price)
│
├── screenshots/                      -> sc1.png and sc2.png saved here
├── testng.xml                        -> TestNG suite config
├── pom.xml                           -> Maven dependencies
└── README.md
```

## How to Run

1. Make sure Java 11+ and Maven are installed
2. Chrome browser should be installed (ChromeDriver is auto-managed)
3. Open project in IntelliJ IDEA or Eclipse as a Maven project
4. Run: `mvn test`  OR right-click `testng.xml` → Run

## Excel Test Data (TestData.xlsx)

| SearchKeyword | SuggestionText       | OSFilter | PriceLimit |
|---------------|----------------------|----------|------------|
| mobile        | mobile under 15000   | Pie      | 30000      |

## Notes

- Screenshots are saved in `/screenshots/` folder (sc1.png, sc2.png)
- WebDriverManager auto-downloads the correct ChromeDriver
- No need to manually set chromedriver path
