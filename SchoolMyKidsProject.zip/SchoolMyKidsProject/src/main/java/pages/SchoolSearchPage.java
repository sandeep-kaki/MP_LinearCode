package pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SchoolSearchPage {

    WebDriver driver;
    WebDriverWait wait;

    // ---- Page Elements ----

    @FindBy(xpath = "//button[contains(text(),'Schools')]")
    WebElement schoolsMenu;

    // ---- Constructor ----

    public SchoolSearchPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        PageFactory.initElements(driver, this);
    }

    // ---- Page Actions ----

    public void hoverOnSchoolsMenu() {
        Actions actions = new Actions(driver);
        actions.moveToElement(schoolsMenu).perform();
    }

    public void selectCity(String city) {
        WebElement cityLink = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//a[@class='dropdown-item' and text()='" + city + "']")));
        cityLink.click();
    }

    public void selectBoardCheckbox(String board) {
        // board_cbse, board_icse etc — id is constructed dynamically from excel value
        String checkboxId = "board_" + board.toLowerCase();
        WebElement checkbox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(checkboxId)));

        // JS click because normal click gets blocked by overlapping elements
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", checkbox);
    }

    public void scrollDownAndBack() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        Thread.sleep(2000);
        js.executeScript("window.scrollTo(0, 0)");
        Thread.sleep(3000);
    }

    public boolean isSearchResultsDisplayed() {
        List<WebElement> results = driver.findElements(
                By.xpath("//h3[@class='custom-card-title lising-title d-inline-block']/span"));
        return results.size() > 0;
    }

    public List<String> getSchoolNamesFromFirstPage() {
        List<WebElement> schoolElements = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath("//h3[@class='custom-card-title lising-title d-inline-block']/span")));

        List<String> schoolNames = new ArrayList<>();
        for (WebElement el : schoolElements) {
            schoolNames.add(el.getText());
        }
        return schoolNames;
    }
}
