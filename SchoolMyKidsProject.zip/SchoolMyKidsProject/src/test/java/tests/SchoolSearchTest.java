package tests;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.SchoolSearchPage;
import utils.ConfigReader;
import utils.ExcelReader;

public class SchoolSearchTest {

    WebDriver driver;
    SchoolSearchPage schoolPage;

    @BeforeTest
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get(ConfigReader.get("url"));
        schoolPage = new SchoolSearchPage(driver);
    }

    @Test
    public void searchSchoolsInPuneWithCBSE() throws InterruptedException {

        // Read city and board from Excel
        String city  = ExcelReader.getCellValue("testdata/TestData.xlsx", "SearchData", 1, 0);
        String board = ExcelReader.getCellValue("testdata/TestData.xlsx", "SearchData", 1, 1);

        // Step 1: Hover on Schools menu
        schoolPage.hoverOnSchoolsMenu();

        // Step 2: Select city from dropdown
        schoolPage.selectCity(city);

        // Step 3: Check the board checkbox
        schoolPage.selectBoardCheckbox(board);

        // Step 4: Scroll down to load results, then scroll back up
        schoolPage.scrollDownAndBack();

        // Step 5: Verify search results are displayed
        boolean resultsVisible = schoolPage.isSearchResultsDisplayed();
        Assert.assertTrue(resultsVisible, "Search results should be visible after applying filters.");
        System.out.println("Search results are displayed.");

        // Step 6: Get and print school names from first page
        List<String> schoolNames = schoolPage.getSchoolNamesFromFirstPage();

        System.out.println("Schools found on first page:");
        for (String name : schoolNames) {
            System.out.println(name);
        }
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
