Screenshots taken during test runs will be saved here.
- sc1.png : After applying OS filter
- sc2.png : After sorting by Newest First
