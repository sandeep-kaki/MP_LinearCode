Screenshots are saved here automatically during test run.

sc1.png → Taken after Pie OS filter is applied
sc2.png → Taken after sorting by Newest First
