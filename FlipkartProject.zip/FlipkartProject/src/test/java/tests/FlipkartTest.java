package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.ProductListPage;

public class FlipkartTest extends BaseTest {

    /*
     * Two @Tests — real-world split:
     *
     *  @Test 1 — testSearchFilterAndSort
     *            Covers the full UI flow:
     *            Open site → close popup → search → pick suggestion
     *            → adjust slider → apply OS filter → screenshot
     *            → sort by newest → screenshot
     *
     *  @Test 2 — testValidateTopFiveProducts
     *            Reads top 5 products from the filtered+sorted result
     *            Prints name + price of each
     *            Asserts that the first product's price is < ₹30,000
     *            dependsOnMethods = Test 1 (needs the filtered page to be open)
     */

    // ─────────────────────────────────────────────────────────────────────────
    // TEST 1 : Search → Filter → Sort → Screenshots
    // ─────────────────────────────────────────────────────────────────────────
    @Test(priority = 1)
    public void testSearchFilterAndSort() throws InterruptedException {
        System.out.println("\n========================================");
        System.out.println("TEST 1: Search, Filter and Sort");
        System.out.println("========================================");

        // ── Open Flipkart ────────────────────────────────────────────────────
        driver.get("https://www.flipkart.com/");
        System.out.println("  → Flipkart opened.");

        // ── Home Page: close popup, search, select suggestion ────────────────
        HomePage homePage = new HomePage(driver);
        homePage.closeLoginPopup();
        homePage.enterSearchText("mobile ");
        homePage.selectSuggestion("mobile under 15000");

        // ── Product List Page: slider, filter, screenshot ────────────────────
        ProductListPage productListPage = new ProductListPage(driver);

        productListPage.adjustPriceSlider();
        productListPage.selectOSFilter();
        productListPage.takeScreenshot("sc1.png");  // Screenshot after filter

        // ── Sort and screenshot ──────────────────────────────────────────────
        productListPage.sortByNewest();
        productListPage.takeScreenshot("sc2.png");  // Screenshot after sort

        System.out.println("✅ TEST 1 PASSED: Search, filter and sort completed.\n");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TEST 2 : Read top 5 products → Validate first product price
    // ─────────────────────────────────────────────────────────────────────────
    @Test(priority = 2, dependsOnMethods = "testSearchFilterAndSort")
    public void testValidateTopFiveProducts() {
        System.out.println("\n========================================");
        System.out.println("TEST 2: Validate Top 5 Product Prices");
        System.out.println("========================================");

        ProductListPage productListPage = new ProductListPage(driver);

        int firstProductPrice = 0;

        for (int i = 1; i <= 5; i++) {

            // Wait for name and price explicitly inside the page class methods
            String name  = productListPage.getProductName(i);
            String price = productListPage.getProductPrice(i);

            System.out.println("\n  Product " + i + " : " + name);
            System.out.println("  Price    : " + price);

            // Remove ₹, commas, whitespace — keep only digits
            String cleanPrice = price.replaceAll("[^0-9]", "");
            int priceAsInt    = Integer.parseInt(cleanPrice);

            // Capture first product price for assertion
            if (i == 1) {
                firstProductPrice = priceAsInt;
            }
        }

        // ── Assertion: first product price should be under 30,000 ────────────
        System.out.println("\n  Asserting first product price < ₹30,000...");
        System.out.println("  First product price: ₹" + firstProductPrice);

        Assert.assertTrue(
            firstProductPrice < 30000,
            "VALIDATION FAILED: First product price ₹" + firstProductPrice + " is NOT less than ₹30,000"
        );

        System.out.println("  ✅ ASSERTION PASSED: Price ₹" + firstProductPrice + " is less than ₹30,000");
        System.out.println("\n✅ TEST 2 PASSED: All top 5 products read and validated.\n");
    }
}
