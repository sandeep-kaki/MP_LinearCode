package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.ProductListPage;

public class FlipkartTest extends BaseTest {

    @Test
    public void flipkartMobileSearchTest() throws InterruptedException {

        // ── Step 1: Open Flipkart ─────────────────────────────────────────────
        driver.get("https://www.flipkart.com/");

        // ── Step 2: Home Page — close popup, search, pick suggestion ──────────
        HomePage homePage = new HomePage(driver);
        homePage.closeLoginPopup();
        homePage.enterSearchText("mobile ");
        homePage.selectSuggestion("mobile under 15000");

        // ── Step 3: Product List Page — slider, filter, screenshot, sort ──────
        ProductListPage productListPage = new ProductListPage(driver);

        productListPage.adjustPriceSlider();
        productListPage.selectOSFilter();
        productListPage.takeScreenshot("sc1.png");  // Screenshot 1 — after filter

        productListPage.sortByNewest();
        productListPage.takeScreenshot("sc2.png");  // Screenshot 2 — after sorting

        // ── Step 4: Print top 5 products + validate 1st product price ─────────
        for (int i = 1; i <= 5; i++) {

            String name  = productListPage.getProductName(i);
            String price = productListPage.getProductPrice(i);

            System.out.println("\n" + i + ". " + name);
            System.out.println("   Price : " + price);

            // Remove ₹, commas, spaces — keep only digits
            String cleanPrice = price.replaceAll("[^0-9]", "");
            int priceAsInt = Integer.parseInt(cleanPrice);

            // Validate only the first product
            if (i == 1) {
                System.out.println("   Validating first product price...");
                Assert.assertTrue(
                    priceAsInt < 30000,
                    "VALIDATION FAILED: First product price ₹" + priceAsInt + " is NOT less than 30000"
                );
                System.out.println("   ✅ VALIDATION PASSED: Price ₹" + priceAsInt + " is less than 30000");
            }
        }
    }
}
