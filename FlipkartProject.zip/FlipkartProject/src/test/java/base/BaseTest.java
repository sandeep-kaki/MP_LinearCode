package base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BaseTest {

    // protected — accessible in FlipkartTest which extends this class
    protected WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Automatically downloads & sets up the correct ChromeDriver version
        WebDriverManager.chromedriver().setup();

        driver = new ChromeDriver();

        // ✅ NO implicit wait here — we use explicit waits in every page class
        //    Mixing implicit + explicit waits causes unpredictable timeouts

        driver.manage().window().maximize();
        System.out.println("✅ Browser launched successfully.");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            System.out.println("✅ Browser closed successfully.");
        }
    }
}
