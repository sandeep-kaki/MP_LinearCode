package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.time.Duration;

public class ProductListPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // Timeout constants
    private static final int DEFAULT_TIMEOUT = 15;
    private static final int SLIDER_TIMEOUT  = 20; // page can take longer after search redirect

    public ProductListPage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(DEFAULT_TIMEOUT));
    }

    // ── Method 1: Wait for page to load, then drag price slider left ─────────
    public void adjustPriceSlider() {
        // Use longer timeout — product list page can be slow to fully render
        WebDriverWait sliderWait = new WebDriverWait(driver, Duration.ofSeconds(SLIDER_TIMEOUT));

        // Wait until slider is visible and interactable
        WebElement maxSlider = sliderWait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@id='container']//div[@class='lPYKVv jVLYlZ']")
            )
        );

        // Also wait until it is clickable before dragging
        sliderWait.until(ExpectedConditions.elementToBeClickable(maxSlider));

        Actions slider = new Actions(driver);
        slider.dragAndDropBy(maxSlider, -175, 0).perform();
        System.out.println("  → Price slider adjusted.");
    }

    // ── Method 2: Expand OS filter section, show more, select Pie ────────────
    public void selectOSFilter() {
        // Step 2a: Click the "Operating System Version Name" section header
        WebElement osSection = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//div[text()='Operating System Version Name']/parent::div")
            )
        );
        osSection.click();
        System.out.println("  → OS filter section expanded.");

        // Step 2b: Wait for the "__ More" link to appear, then click it
        WebElement moreLink = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//div[text()='Operating System Version Name']/parent::*/following-sibling::*//span")
            )
        );
        moreLink.click();
        System.out.println("  → 'More' link clicked to reveal all OS options.");

        // Step 2c: Wait for "Pie" option to appear, then click via JS
        //          JS click used because the checkbox can be hidden behind overlay
        WebElement pieCheckbox = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//*[text()='Pie']/preceding-sibling::div")
            )
        );
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", pieCheckbox);
        System.out.println("  → 'Pie' OS filter selected.");

        // Wait for the filtered results to reload after applying filter
        wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("(//*[@class='col col-7-12']/div[@class='RG5Slk'])[1]")
            )
        );
        System.out.println("  → Filtered results loaded.");
    }

    // ── Method 3: Click "Newest First" sort, wait for results to reload ──────
    public void sortByNewest() {
        WebElement newestFirst = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//*[text()='Newest First']")
            )
        );
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", newestFirst);
        System.out.println("  → Sorted by 'Newest First'.");

        // Wait for the first product to be visible again after sort reload
        wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("(//*[@class='col col-7-12']/div[@class='RG5Slk'])[1]")
            )
        );
        System.out.println("  → Results reloaded after sort.");
    }

    // ── Method 4: Take and save a screenshot ─────────────────────────────────
    public void takeScreenshot(String fileName) {
        String screenshotDir = System.getProperty("user.dir") + File.separator + "screenshots";

        // Create screenshots folder if it doesn't already exist
        File dir = new File(screenshotDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        TakesScreenshot ts  = (TakesScreenshot) driver;
        File sourceFile     = ts.getScreenshotAs(OutputType.FILE);
        File targetFile     = new File(screenshotDir + File.separator + fileName);
        boolean saved       = sourceFile.renameTo(targetFile);

        if (saved) {
            System.out.println("  → Screenshot saved: " + targetFile.getAbsolutePath());
        } else {
            System.out.println("  ⚠ Screenshot could not be saved: " + fileName);
        }
    }

    // ── Method 5: Get product name by 1-based position ───────────────────────
    public String getProductName(int index) {
        return wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("(//*[@class='col col-7-12']/div[@class='RG5Slk'])[" + index + "]")
            )
        ).getText();
    }

    // ── Method 6: Get product price by 1-based position ──────────────────────
    public String getProductPrice(int index) {
        return wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("(//*[@class='oFEPlD']//*[@class='hZ3P6w DeU9vF'])[" + index + "]")
            )
        ).getText();
    }
}
