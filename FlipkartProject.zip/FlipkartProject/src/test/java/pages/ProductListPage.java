package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.time.Duration;

public class ProductListPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // Constructor receives driver from the test class
    public ProductListPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // Drags the max price slider to the left by 175px
    public void adjustPriceSlider() throws InterruptedException {
        Thread.sleep(3000); // wait for page to fully load after search

        Actions slider = new Actions(driver);
        WebElement max = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@id='container']//div[@class='lPYKVv jVLYlZ']")
            )
        );
        slider.dragAndDropBy(max, -175, 0).perform();
    }

    // Opens the OS filter, clicks "more", selects "Pie"
    public void selectOSFilter() {
        // Click on the "Operating System Version Name" section to expand it
        WebElement ele = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//div[text()='Operating System Version Name']/parent::div")
            )
        );
        ele.click();

        // Click the "__ More" link to show all options
        wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//div[text()='Operating System Version Name']/parent::*/following-sibling::*//span")
            )
        ).click();

        // Select "Pie" checkbox using JavaScript click (avoids element-not-interactable issue)
        WebElement pieOS = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//*[text()='Pie']/preceding-sibling::div")
            )
        );
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", pieOS);
    }

    // Takes a screenshot and saves it to the /screenshots folder
    public void takeScreenshot(String fileName) {
        // Build path: project root + screenshots folder + filename
        String screenshotDir = System.getProperty("user.dir") + File.separator + "screenshots";

        // Create the screenshots folder if it doesn't exist
        File dir = new File(screenshotDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        TakesScreenshot ts = (TakesScreenshot) driver;
        File sourceFile = ts.getScreenshotAs(OutputType.FILE);
        File targetFile = new File(screenshotDir + File.separator + fileName);
        sourceFile.renameTo(targetFile);

        System.out.println("Screenshot saved: " + targetFile.getAbsolutePath());
    }

    // Clicks the "Newest First" sort option
    public void sortByNewest() throws InterruptedException {
        WebElement newestFirst = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//*[text()='Newest First']")
            )
        );
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", newestFirst);
        Thread.sleep(2000); // wait for results to reload
    }

    // Returns product name by position (1-based index)
    public String getProductName(int index) {
        return wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("(//*[@class='col col-7-12']/div[@class='RG5Slk'])[" + index + "]")
            )
        ).getText();
    }

    // Returns product price by position (1-based index)
    public String getProductPrice(int index) {
        return wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("(//*[@class='oFEPlD']//*[@class='hZ3P6w DeU9vF'])[" + index + "]")
            )
        ).getText();
    }
}
