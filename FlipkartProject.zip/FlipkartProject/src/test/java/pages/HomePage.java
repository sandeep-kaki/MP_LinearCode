package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class HomePage {

    private WebDriver driver;
    private WebDriverWait wait;

    // Constructor receives driver from the test class
    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // Closes the login popup that appears on Flipkart homepage
    public void closeLoginPopup() {
        driver.findElement(
            By.xpath("//*[@class='q7ywiQ']/span[@role='button']")
        ).click();
    }

    // Types text in the search box
    public void enterSearchText(String text) throws InterruptedException {
        WebElement search = driver.findElement(By.name("q"));
        search.sendKeys(text);
        Thread.sleep(1000); // small wait for suggestions to appear
    }

    // Picks the matching suggestion from the dropdown
    public void selectSuggestion(String suggestionText) {
        List<WebElement> suggests = wait.until(
            ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath("//div[@class='lfFUxn']//li")
            )
        );

        for (WebElement x : suggests) {
            if (x.getText().toLowerCase().contains(suggestionText.toLowerCase())) {
                x.click();
                break;
            }
        }
    }
}
