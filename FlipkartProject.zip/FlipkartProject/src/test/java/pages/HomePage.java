package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class HomePage {

    private WebDriver driver;
    private WebDriverWait wait;

    // Timeout constants — easy to change in one place
    private static final int DEFAULT_TIMEOUT  = 15;
    private static final int SUGGESTION_TIMEOUT = 10;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(DEFAULT_TIMEOUT));
    }

    // ── Method 1: Close the login popup ──────────────────────────────────────
    public void closeLoginPopup() {
        // Wait until the close button is clickable, then click
        WebElement closeBtn = wait.until(
            ExpectedConditions.elementToBeClickable(
                By.xpath("//*[@class='q7ywiQ']/span[@role='button']")
            )
        );
        closeBtn.click();
        System.out.println("  → Login popup closed.");
    }

    // ── Method 2: Type in the search box ─────────────────────────────────────
    public void enterSearchText(String text) {
        // Wait until the search input is visible and interactable
        WebElement searchBox = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.name("q")
            )
        );
        searchBox.clear();
        searchBox.sendKeys(text);
        System.out.println("  → Search text entered: " + text);
    }

    // ── Method 3: Pick the matching suggestion from dropdown ─────────────────
    public void selectSuggestion(String suggestionText) {
        // Use a shorter wait specifically for suggestions to load
        WebDriverWait suggestionWait = new WebDriverWait(driver, Duration.ofSeconds(SUGGESTION_TIMEOUT));

        // Wait until the suggestion list items are all visible
        List<WebElement> suggestions = suggestionWait.until(
            ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath("//div[@class='lfFUxn']//li")
            )
        );

        System.out.println("  → Suggestions loaded. Total: " + suggestions.size());

        boolean found = false;
        for (WebElement suggestion : suggestions) {
            // Wait for each suggestion text to be visible before reading
            String text = suggestion.getText().toLowerCase();
            if (text.contains(suggestionText.toLowerCase())) {
                wait.until(ExpectedConditions.elementToBeClickable(suggestion)).click();
                System.out.println("  → Suggestion selected: " + suggestion.getText());
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("  ⚠ Suggestion not found: " + suggestionText);
        }
    }
}
