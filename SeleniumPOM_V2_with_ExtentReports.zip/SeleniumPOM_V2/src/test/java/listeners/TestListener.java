package listeners;

// ============================================================
// NEW FILE — Added for Extent Reports integration
// Implements ITestListener to capture test lifecycle events:
//   - onTestStart   → logs test name
//   - onTestSuccess → marks test PASS
//   - onTestFailure → marks test FAIL with error message
//   - onTestSkipped → marks test SKIPPED
//   - onFinish      → flushes the report (writes HTML file)
//
// Registered in testng.xml — no existing test classes are changed.
// ============================================================

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import utils.ExtentReportManager;

public class TestListener implements ITestListener {

    // Shared ExtentReports instance from the manager utility
    private static ExtentReports extent = ExtentReportManager.getInstance();

    // ThreadLocal so each test thread gets its own ExtentTest node
    // (safe for parallel runs; harmless for single-threaded runs)
    private static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();

    // ----------------------------------------------------------
    // Called when a test method starts
    // ----------------------------------------------------------
    @Override
    public void onTestStart(ITestResult result) {
        // Create a new test node in the report with the test method name
        ExtentTest test = extent.createTest(result.getMethod().getMethodName());
        extentTest.set(test);

        // Log test start info
        extentTest.get().log(Status.INFO, "Test Started: " + result.getMethod().getMethodName());
    }

    // ----------------------------------------------------------
    // Called when a test method passes
    // ----------------------------------------------------------
    @Override
    public void onTestSuccess(ITestResult result) {
        extentTest.get().log(Status.PASS, "Test Passed: " + result.getMethod().getMethodName());
    }

    // ----------------------------------------------------------
    // Called when a test method fails
    // ----------------------------------------------------------
    @Override
    public void onTestFailure(ITestResult result) {
        // Log FAIL status and include the actual error/exception message
        extentTest.get().log(Status.FAIL, "Test Failed: " + result.getMethod().getMethodName());
        extentTest.get().log(Status.FAIL, "Reason: " + result.getThrowable().getMessage());
    }

    // ----------------------------------------------------------
    // Called when a test method is skipped
    // ----------------------------------------------------------
    @Override
    public void onTestSkipped(ITestResult result) {
        extentTest.get().log(Status.SKIP, "Test Skipped: " + result.getMethod().getMethodName());
    }

    // ----------------------------------------------------------
    // Called after ALL tests in the suite finish
    // This writes (flushes) the HTML report file to disk
    // ----------------------------------------------------------
    @Override
    public void onFinish(ITestContext context) {
        if (extent != null) {
            extent.flush();  // <-- This generates the final HTML report
            System.out.println("===== Extent Report generated at: reports/ExtentReport.html =====");
        }
    }

    // ----------------------------------------------------------
    // Unused lifecycle methods — kept to satisfy ITestListener
    // ----------------------------------------------------------
    @Override public void onTestFailedButWithinSuccessPercentage(ITestResult result) {}
    @Override public void onStart(ITestContext context) {}
}
