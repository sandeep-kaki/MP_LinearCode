package utils;

// ============================================================
// NEW FILE — Added for Extent Reports integration
// Utility class to initialize and manage ExtentReports.
// This class is only called from TestListener.java.
// No existing files are modified by this class.
// ============================================================

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReportManager {

    // Single shared instance of ExtentReports (used across all tests)
    private static ExtentReports extent;

    /**
     * Returns the shared ExtentReports instance.
     * Creates it on first call (lazy initialization).
     * Report file will be generated at: reports/ExtentReport.html
     */
    public static ExtentReports getInstance() {

        if (extent == null) {

            // --- Configure the HTML reporter (Spark = modern built-in reporter) ---
            ExtentSparkReporter sparkReporter = new ExtentSparkReporter("reports/ExtentReport.html");

            // Basic visual settings
            sparkReporter.config().setDocumentTitle("Automation Test Report");
            sparkReporter.config().setReportName("SeleniumPOM_V2 - Test Results");
            sparkReporter.config().setTheme(Theme.STANDARD);
            sparkReporter.config().setEncoding("UTF-8");

            // --- Attach reporter to ExtentReports ---
            extent = new ExtentReports();
            extent.attachReporter(sparkReporter);

            // Optional: add system/environment info shown in the report
            extent.setSystemInfo("Project",     "SeleniumPOM_V2");
            extent.setSystemInfo("Framework",   "Selenium + TestNG");
            extent.setSystemInfo("Author",      "QA Team");
        }

        return extent;
    }
}
