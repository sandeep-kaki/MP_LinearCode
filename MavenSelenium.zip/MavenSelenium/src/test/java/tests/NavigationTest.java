package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import navigationCommands.GooglePage;
import navigationCommands.OrangeHRMPage;

public class NavigationTest {

    public static void main(String[] args) throws Exception {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        GooglePage google = new GooglePage(driver);
        OrangeHRMPage orange = new OrangeHRMPage(driver);

        // === GOOGLE STEPS ===
        google.openGoogle();
        google.searchText("Orange HRM demo");

        google.back();
        google.back();
//        Thread.sleep(2000);

        google.forward();
       


        // === ORANGEHRM STEPS ===
        orange.openNewTab();
        orange.clickContactSales();
        orange.fillForm();
//        Thread.sleep(1000);
        orange.clickCookies();

        orange.clickCaptcha();
        orange.submitOnce();

        orange.takeScreenshot();

        orange.enterMessageAndSubmit();

//        Thread.sleep(2000);
        driver.close();
//        Thread.sleep(2000);
        driver.quit();
    }
}