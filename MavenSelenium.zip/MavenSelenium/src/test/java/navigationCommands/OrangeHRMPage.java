package navigationCommands;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;
import java.io.File;
//import java.nio.file.*;

public class OrangeHRMPage {

    WebDriver driver;
    WebDriverWait wait;

    By contactSales = By.linkText("Contact Sales");
    By fullName = By.name("FullName");
    By phone = By.name("Contact");
    By jobTitle = By.name("JobTitle");
    By country = By.name("Country");
    By employees = By.name("NoOfEmployees");
    By email = By.name("Email");
    By companyName = By.name("CompanyName");
    By messageBox = By.name("Comment");
    By allowCookies = By.id("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll");

    public OrangeHRMPage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(100));
    }

    public void openNewTab() {
        driver.switchTo().newWindow(WindowType.TAB);
        driver.navigate().to("https://www.orangehrm.com/");
    }

    public void clickContactSales() {
        WebElement cs = wait.until(ExpectedConditions.elementToBeClickable(contactSales));
        cs.click();
    }

    public void fillForm() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(fullName)).sendKeys("Vikram Rathode");
        driver.findElement(phone).sendKeys("1234567890");
        driver.findElement(jobTitle).sendKeys("Fresher");

        new Select(driver.findElement(country)).selectByVisibleText("India");
        new Select(driver.findElement(employees)).selectByVisibleText("11 - 50");

        driver.findElement(email).sendKeys("rathodeitsolutions.test@test.com");

        driver.findElement(By.className("textarea")).click();
        driver.findElement(companyName).sendKeys("Test Company");
    }

    public void clickCookies() {
        try {
            driver.findElement(allowCookies).click();
        } catch (Exception e) {}
    }

    public void clickCaptcha() throws InterruptedException {
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(
                By.cssSelector("iframe[title='reCAPTCHA']")));

        WebElement cap = wait.until(ExpectedConditions.elementToBeClickable(By.id("recaptcha-anchor")));
        cap.click();
        

        new WebDriverWait(driver, Duration.ofSeconds(80))
        .until(ExpectedConditions.attributeToBe(By.id("recaptcha-anchor"), "aria-checked", "true"));


        driver.switchTo().defaultContent();
//        Thread.sleep(80000);  // SAME as your code
    }

    public void submitOnce() {
        WebElement submit = driver.findElement(By.id("Form_getForm_action_submitForm"));
        submit.submit();
    }

    public void takeScreenshot() throws Exception {
        TakesScreenshot ts = (TakesScreenshot)driver;
        File src = ts.getScreenshotAs(OutputType.FILE);
        
        File target = new File(System.getProperty("user.dir")+"\\screenshots\\screenshot1.png");
        src.renameTo(target);
        

//        Path dir = Paths.get("screenshots");
//        Files.createDirectories(dir);
//        Path target = dir.resolve("screenshot.png");
//
//        Files.copy(src.toPath(), target, StandardCopyOption.REPLACE_EXISTING);
    }

    public void enterMessageAndSubmit() throws InterruptedException {
        driver.findElement(messageBox).sendKeys("This is a test message");

        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(
                By.cssSelector("iframe[title='reCAPTCHA']")));

        WebElement cap2 = wait.until(ExpectedConditions.elementToBeClickable(By.id("recaptcha-anchor")));
        cap2.click();
        
        new WebDriverWait(driver, Duration.ofSeconds(40))
        .until(ExpectedConditions.attributeToBe(By.id("recaptcha-anchor"), "aria-checked", "true"));

        driver.switchTo().defaultContent();

//        Thread.sleep(30000);
        WebElement submit2 = driver.findElement(By.name("action_submitForm"));
        submit2.submit();
    }
}