package navigationCommands;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;

public class GooglePage {

    WebDriver driver;
    WebDriverWait wait;

    By searchBox = By.name("q");
    By results = By.id("search");

    public GooglePage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(80));
    }

    public void openGoogle() {
        driver.get("https://google.com/");
    }

    public void searchText(String text) {
        WebElement box = wait.until(ExpectedConditions.visibilityOfElementLocated(searchBox));
        box.sendKeys(text, Keys.ENTER);
        wait.until(ExpectedConditions.presenceOfElementLocated(results));
        System.out.println("Search Result displayed");
    }

    public void back() {
        driver.navigate().back();
    }

//    public void backAgain() {
//        driver.navigate().back();
//        System.out.println("After clicking on back arrow button " + driver.getCurrentUrl());
//    }

    public void forward() {
        driver.navigate().forward();
        wait.until(ExpectedConditions.presenceOfElementLocated(results));
//        System.out.println("After clicking on forward arrow button " + driver.getCurrentUrl());
    }
}






